# HEALTHIFY

A Gemini-first health companion with a simple, senior-friendly UI, Clerk authentication, MongoDB persistence, and cautious health education workflows.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm --filter @workspace/healthify run dev` — run the web app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- Required secrets: `GEMINI_API_KEY`, `MONGODB_URI`, `MONGODB_DB_NAME` (optional; defaults to `healthify`), plus Clerk secrets provisioned by Replit Auth.

## Stack

- pnpm workspaces, Node.js, TypeScript
- Frontend: React + Vite + Tailwind/shadcn-style components
- Authentication: Clerk
- API: Express 5
- AI: Google Gemini 2.5 Flash, called server-side only
- Database: MongoDB Atlas via the official MongoDB Node.js driver
- Validation: Zod and generated API contracts
- Build: Vite + esbuild

## Architecture

- Browser requests never receive the Gemini or MongoDB credentials.
- Clerk identifies the signed-in user; server routes derive ownership from the authenticated Clerk session.
- Gemini is the primary intelligence layer for health chat, report explanation, wellness suggestions, and meal ideas.
- MongoDB persists user-owned reminders and family members. Health reports remain transient.
- Demo wearable/care-provider values are not presented as real data.

## Important product safety

HEALTHIFY is an educational companion, not a clinician or emergency service. AI responses use explicit safety instructions, emergency pre-routing, conservative wellness guidance, and schema validation. Never fabricate provider listings, medical results, or device measurements.

## Gotchas

- Run `pnpm install` after changing dependencies so `pnpm-lock.yaml` is regenerated.
- Add secrets through Replit Secrets; never commit them or expose them as `VITE_` variables.
- MongoDB Atlas network access must allow the Replit deployment.
- Report uploads are intentionally not persisted.
