import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { getAuth } from "@clerk/express";

const router: IRouter = Router();

function requireUser(req: Request, res: Response, next: NextFunction): void {
  if (!getAuth(req).userId) {
    res.status(401).json({ error: "Please sign in first." });
    return;
  }
  next();
}

router.get("/care/search", requireUser, async (req, res) => {
  const query = typeof req.query.query === "string" ? req.query.query.trim() : "";
  const location = typeof req.query.location === "string" ? req.query.location.trim() : "";
  if (!query || query.length > 100 || !location || location.length > 160) {
    res.status(400).json({ error: "Enter a care type and location." });
    return;
  }

  const apiKey = process.env.GOOGLE_MAPS_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "Live care search is not configured yet." });
    return;
  }

  try {
    const response = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": apiKey,
        "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress,places.location,places.googleMapsUri",
      },
      body: JSON.stringify({
        textQuery: `${query} near ${location}`,
        pageSize: 10,
      }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!response.ok) {
      req.log.warn({ status: response.status }, "Google Places search failed");
      res.status(502).json({ error: "The provider search service is unavailable right now." });
      return;
    }
    const body = await response.json() as {
      places?: Array<{
        id?: string;
        displayName?: { text?: string };
        formattedAddress?: string;
        location?: { latitude?: number; longitude?: number };
        googleMapsUri?: string;
      }>;
    };
    res.json({
      providers: (body.places ?? []).map((place) => ({
        id: place.id ?? "",
        name: place.displayName?.text ?? "Unnamed provider",
        address: place.formattedAddress ?? "Address unavailable",
        latitude: place.location?.latitude ?? null,
        longitude: place.location?.longitude ?? null,
        mapsUrl: place.googleMapsUri ?? null,
      })),
    });
  } catch (error) {
    req.log.error({ error }, "Care search request failed");
    res.status(502).json({ error: "The provider search service is unavailable right now." });
  }
});

export default router;
