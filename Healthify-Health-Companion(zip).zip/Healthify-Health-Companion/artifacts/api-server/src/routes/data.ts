import { getAuth } from "@clerk/express";
import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { getCollection, toObjectId } from "@workspace/db";

const router: IRouter = Router();

type Reminder = {
  _id?: unknown;
  userId: string;
  title: string;
  time: string;
  dateLabel: string;
  enabled: boolean;
  createdAt: Date;
  updatedAt: Date;
};

type FamilyMember = {
  _id?: unknown;
  ownerId: string;
  name: string;
  relation: string;
  age?: number;
  permission: "View" | "Edit" | "No access";
  createdAt: Date;
  updatedAt: Date;
};

function requireUser(req: Request, res: Response, next: NextFunction): void {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Please sign in first." });
    return;
  }
  res.locals.userId = userId;
  next();
}

function userId(req: Request): string {
  return res.locals.userId as string;
}

function safeReminder(body: unknown): { title: string; time: string; dateLabel: string; enabled: boolean } | null {
  if (!body || typeof body !== "object") return null;
  const b = body as Record<string, unknown>;
  const title = typeof b.title === "string" ? b.title.trim() : "";
  const time = typeof b.time === "string" ? b.time.trim() : "";
  const dateLabel = typeof b.dateLabel === "string" ? b.dateLabel.trim() : "Tomorrow";
  const enabled = typeof b.enabled === "boolean" ? b.enabled : true;
  if (!title || title.length > 80 || !/^\d{2}:\d{2}$/.test(time)) return null;
  return { title, time, dateLabel: dateLabel.slice(0, 40) || "Tomorrow", enabled };
}

router.get("/data/reminders", requireUser, async (req, res) => {
  try {
    const collection = await getCollection<Reminder>("reminders");
    const rows = await collection.find({ userId: userId(req) }).sort({ createdAt: -1 }).toArray();
    res.json(rows.map((r) => ({ id: String(r._id), title: r.title, time: r.time, dateLabel: r.dateLabel, enabled: r.enabled })));
  } catch (error) {
    req.log.error({ error }, "Failed to load reminders");
    res.status(503).json({ error: "Database is unavailable." });
  }
});

router.post("/data/reminders", requireUser, async (req, res) => {
  const value = safeReminder(req.body);
  if (!value) {
    res.status(400).json({ error: "Enter a title and a valid time." });
    return;
  }
  try {
    const now = new Date();
    const collection = await getCollection<Reminder>("reminders");
    const result = await collection.insertOne({ ...value, userId: userId(req), createdAt: now, updatedAt: now });
    res.status(201).json({ id: String(result.insertedId), ...value });
  } catch (error) {
    req.log.error({ error }, "Failed to create reminder");
    res.status(503).json({ error: "Database is unavailable." });
  }
});

router.patch("/data/reminders/:id", requireUser, async (req, res) => {
  const id = toObjectId(req.params.id);
  if (!id || !req.body || typeof req.body.enabled !== "boolean") {
    res.status(400).json({ error: "Invalid reminder update." });
    return;
  }
  try {
    const collection = await getCollection<Reminder>("reminders");
    const result = await collection.findOneAndUpdate(
      { _id: id, userId: userId(req) },
      { $set: { enabled: req.body.enabled, updatedAt: new Date() } },
      { returnDocument: "after" },
    );
    if (!result) {
      res.status(404).json({ error: "Reminder not found." });
      return;
    }
    res.json({ id: String(result._id), title: result.title, time: result.time, dateLabel: result.dateLabel, enabled: result.enabled });
  } catch (error) {
    req.log.error({ error }, "Failed to update reminder");
    res.status(503).json({ error: "Database is unavailable." });
  }
});

router.delete("/data/reminders/:id", requireUser, async (req, res) => {
  const id = toObjectId(req.params.id);
  if (!id) {
    res.status(400).json({ error: "Invalid reminder id." });
    return;
  }
  try {
    const collection = await getCollection<Reminder>("reminders");
    await collection.deleteOne({ _id: id, userId: userId(req) });
    res.status(204).end();
  } catch (error) {
    req.log.error({ error }, "Failed to delete reminder");
    res.status(503).json({ error: "Database is unavailable." });
  }
});

router.get("/data/family", requireUser, async (req, res) => {
  try {
    const collection = await getCollection<FamilyMember>("family_members");
    const rows = await collection.find({ ownerId: userId(req) }).sort({ createdAt: 1 }).toArray();
    res.json(rows.map((r) => ({
      id: String(r._id), name: r.name, relation: r.relation, age: r.age, permission: r.permission,
    })));
  } catch (error) {
    req.log.error({ error }, "Failed to load family members");
    res.status(503).json({ error: "Database is unavailable." });
  }
});

router.post("/data/family", requireUser, async (req, res) => {
  const body = req.body as Record<string, unknown>;
  const name = typeof body?.name === "string" ? body.name.trim() : "";
  const relation = typeof body?.relation === "string" ? body.relation.trim() : "";
  const age = typeof body?.age === "number" ? body.age : undefined;
  if (!name || name.length > 100 || !relation || relation.length > 60 || (age !== undefined && (age < 0 || age > 120))) {
    res.status(400).json({ error: "Enter a valid name and relationship." });
    return;
  }
  try {
    const now = new Date();
    const collection = await getCollection<FamilyMember>("family_members");
    const result = await collection.insertOne({
      ownerId: userId(req), name, relation, age, permission: "No access", createdAt: now, updatedAt: now,
    });
    res.status(201).json({ id: String(result.insertedId), name, relation, age, permission: "No access" });
  } catch (error) {
    req.log.error({ error }, "Failed to create family member");
    res.status(503).json({ error: "Database is unavailable." });
  }
});

router.patch("/data/family/:id", requireUser, async (req, res) => {
  const id = toObjectId(req.params.id);
  const permission = req.body?.permission;
  if (!id || !["View", "Edit", "No access"].includes(permission)) {
    res.status(400).json({ error: "Invalid permission." });
    return;
  }
  try {
    const collection = await getCollection<FamilyMember>("family_members");
    const result = await collection.findOneAndUpdate(
      { _id: id, ownerId: userId(req) },
      { $set: { permission, updatedAt: new Date() } },
      { returnDocument: "after" },
    );
    if (!result) {
      res.status(404).json({ error: "Family member not found." });
      return;
    }
    res.json({ id: String(result._id), name: result.name, relation: result.relation, age: result.age, permission: result.permission });
  } catch (error) {
    req.log.error({ error }, "Failed to update family permission");
    res.status(503).json({ error: "Database is unavailable." });
  }
});

router.delete("/data/family/:id", requireUser, async (req, res) => {
  const id = toObjectId(req.params.id);
  if (!id) {
    res.status(400).json({ error: "Invalid family member id." });
    return;
  }
  try {
    const collection = await getCollection<FamilyMember>("family_members");
    await collection.deleteOne({ _id: id, ownerId: userId(req) });
    res.status(204).end();
  } catch (error) {
    req.log.error({ error }, "Failed to delete family member");
    res.status(503).json({ error: "Database is unavailable." });
  }
});

export default router;
