import { Router, type IRouter } from "express";
import healthRouter from "./health";
import aiRouter from "./ai";
import dataRouter from "./data";
import careRouter from "./care";

const router: IRouter = Router();

router.use(healthRouter);
router.use(aiRouter);
router.use(dataRouter);
router.use(careRouter);

export default router;
