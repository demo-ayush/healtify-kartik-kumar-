import { createContext, type FormEvent, type ReactNode, useContext, useEffect, useRef, useState, useCallback } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { Route, Switch, Link, Redirect, Router as WouterRouter, useLocation, useRoute } from 'wouter';
import {
  Activity, ArrowRight, Bell, CalendarDays, CheckCircle2,
  ChevronDown, ChevronLeft, ChevronRight, CircleHelp, Clock3, FileHeart, FileText, Heart, HeartPulse,
  Home, Info, Leaf, LockKeyhole, LogOut, Menu, Mic, Moon, MoreHorizontal, Plus, Search, Send,
  ShieldCheck, Sparkles, Stethoscope, Sun, UserRound, UsersRound, Volume2, X, Utensils,
  Watch, Wind, Upload, LoaderCircle, AlertTriangle, Trash2, Pencil, Eye,
  Accessibility, Languages, BellRing, Droplets, Salad, type LucideIcon,
} from 'lucide-react';
import {
  useAnalyzeHealthReport, useGenerateDietPlan, useGenerateWellnessPlan, useHealthCheck, useSendHealthChat,
} from '@workspace/api-client-react';
import type { DietPlanInput, ReportAnalysisInput, WellnessPlanInput } from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';
import '@/index.css';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const stripBase = (path: string) => basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
const brandLogo = `${window.location.origin}${basePath}/logo.svg`;
const disclaimer = 'Healthify shares general educational information only. It is not a diagnosis or a substitute for professional medical advice.';
const grandparentModeStorageKey = 'healthify-grandparent-mode';

type GrandparentModeContextValue = {
  enabled: boolean;
  setEnabled: (enabled: boolean) => void;
};
const GrandparentModeContext = createContext<GrandparentModeContextValue | null>(null);

function readSavedGrandparentMode(): boolean {
  try {
    return window.localStorage.getItem(grandparentModeStorageKey) === 'on';
  } catch {
    return false;
  }
}

function GrandparentModeProvider({ children }: { children: ReactNode }) {
  const [enabled, setEnabled] = useState(readSavedGrandparentMode);
  useEffect(() => {
    document.documentElement.classList.toggle('grandparent-mode', enabled);
    try {
      window.localStorage.setItem(grandparentModeStorageKey, enabled ? 'on' : 'off');
    } catch {
      // Keep the setting usable for this session when browser storage is unavailable.
    }
  }, [enabled]);
  useEffect(() => () => document.documentElement.classList.remove('grandparent-mode'), []);
  return <GrandparentModeContext.Provider value={{ enabled, setEnabled }}>{children}</GrandparentModeContext.Provider>;
}

function useGrandparentMode() {
  const context = useContext(GrandparentModeContext);
  if (!context) throw new Error('Grandparents mode must be used inside its provider.');
  return context;
}

function GrandparentModeSwitch({ className = '' }: { className?: string }) {
  const { enabled, setEnabled } = useGrandparentMode();
  return <button
    type="button"
    role="switch"
    aria-checked={enabled}
    aria-label={`Grandparents mode ${enabled ? 'on' : 'off'}. Larger text and buttons; AI suggestions and voice replies in Hindi.`}
    aria-describedby="grandparent-mode-description"
    data-testid="switch-grandparent-mode"
    onClick={() => setEnabled(!enabled)}
    className={`inline-flex min-h-12 items-center gap-2.5 rounded-xl border px-3 text-left transition ${enabled ? 'border-[#0F766E] bg-[#E7F5F1] text-[#0F625A]' : 'border-[#D8E7E3] bg-white text-[#46645E]'} ${className}`}
  >
    <Accessibility size={19} className="shrink-0"/>
    <span className="min-w-0 leading-tight">
      <span className="block text-xs font-bold">Grandparents mode</span>
      <span className="mt-0.5 block text-[11px] font-semibold" lang="hi">{enabled ? 'ON · चालू' : 'OFF · बंद'}</span>
    </span>
    <span aria-hidden="true" className={`ml-auto grid size-5 shrink-0 place-items-center rounded-full ${enabled ? 'bg-[#0F766E] text-white' : 'bg-[#D9E5E1] text-[#68817B]'}`}>
      {enabled ? <CheckCircle2 size={14}/> : <span className="size-1.5 rounded-full bg-current"/>}
    </span>
    <span id="grandparent-mode-description" className="sr-only">When on, text and controls are larger, and AI suggestions and spoken replies are in Hindi.</span>
  </button>;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: brandLogo },
  variables: {
    colorPrimary: '#0F766E', colorForeground: '#24413F', colorMutedForeground: '#627875',
    colorDanger: '#B9473E', colorBackground: '#FFFFFF', colorInput: '#FBFEFD',
    colorInputForeground: '#24413F', colorNeutral: '#D5E5E1', fontFamily: 'DM Sans, sans-serif', borderRadius: '0.85rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-white rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#24413F] font-semibold', headerSubtitle: 'text-[#627875]',
    socialButtonsBlockButtonText: 'text-[#24413F] font-medium', formFieldLabel: 'text-[#24413F] font-medium',
    footerActionLink: 'text-[#0F766E] font-semibold', footerActionText: 'text-[#627875]', dividerText: 'text-[#627875]',
    identityPreviewEditButton: 'text-[#0F766E]', formFieldSuccessText: 'text-[#0F766E]', alertText: 'text-[#24413F]',
    logoBox: 'mb-3', logoImage: 'h-9', socialButtonsBlockButton: 'rounded-xl border-[#D5E5E1]',
    formButtonPrimary: 'rounded-xl bg-[#0F766E] hover:bg-[#115E59]', formFieldInput: 'rounded-xl border-[#D5E5E1] bg-[#FBFEFD]',
    footerAction: 'text-[#627875]', dividerLine: 'bg-[#D5E5E1]', alert: 'rounded-xl', otpCodeFieldInput: 'rounded-lg',
    formFieldRow: 'gap-2', main: 'gap-4',
  },
};

type IconComp = LucideIcon;
function Logo({ compact = false }: { compact?: boolean }) {
  return <Link href="/" className="inline-flex items-center gap-2.5" data-testid="link-healthify-home">
    <span className="grid size-10 place-items-center rounded-[14px] bg-[#0F766E] text-white shadow-sm"><HeartPulse size={21} strokeWidth={2.5}/></span>
    {!compact && <span className="font-[Manrope] text-[19px] font-extrabold tracking-[-.055em] text-[#1C4541]">healthify<span className="text-[#14B8A6]">.</span></span>}
  </Link>;
}
function Button({ children, variant = 'primary', className = '', onClick, type = 'button', disabled, testId, ...rest }: {
  children: ReactNode; variant?: 'primary'|'outline'|'quiet'|'danger'; className?: string; onClick?: () => void; type?: 'button'|'submit'; disabled?: boolean; testId: string; 'aria-label'?: string;
}) {
  const styles = { primary:'bg-[#0F766E] text-white hover:bg-[#115E59] shadow-[0_5px_14px_rgba(15,118,110,.16)]', outline:'border border-[#D6E5E1] bg-white text-[#315B56] hover:bg-[#F3FAF8]', quiet:'text-[#52716D] hover:bg-[#EAF5F2]', danger:'bg-[#FFF1F0] text-[#9F3C34] hover:bg-[#FDE4E1]' };
  return <button {...rest} type={type} disabled={disabled} onClick={onClick} data-testid={testId} className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition duration-200 disabled:cursor-not-allowed disabled:opacity-50 ${styles[variant]} ${className}`}>{children}</button>;
}
function Card({ children, className = '', testId }: { children: ReactNode; className?: string; testId?: string }) {
  return <section data-testid={testId} className={`rounded-[20px] border border-[#E2ECE9] bg-white p-5 shadow-[0_6px_22px_rgba(20,69,64,.035)] sm:p-6 ${className}`}>{children}</section>;
}
function Eyebrow({ children }: { children: ReactNode }) { return <div className="mb-2 text-[11px] font-bold uppercase tracking-[.15em] text-[#71918B]">{children}</div>; }
function PageTitle({ eyebrow, title, text, action }: { eyebrow: string; title: string; text?: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><Eyebrow>{eyebrow}</Eyebrow><h1 className="font-[Manrope] text-[28px] font-bold tracking-[-.045em] text-[#23413E] sm:text-[34px]">{title}</h1>{text && <p className="mt-2 max-w-2xl text-[15px] leading-6 text-[#66807C]">{text}</p>}</div>{action}</div>;
}
function DemoTag() { return <span className="inline-flex items-center gap-1 rounded-full bg-[#FFF4DD] px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.08em] text-[#805A21]"><Info size={12}/> Demo data</span>; }
function Disclaimer() {
  const { enabled } = useGrandparentMode();
  return <div lang={enabled ? 'hi' : undefined} data-testid="text-health-disclaimer" className="mt-5 flex gap-2 rounded-xl border border-[#E4EEEB] bg-[#F6FAF9] px-4 py-3 text-xs leading-5 text-[#607B76]"><ShieldCheck size={15} className="mt-0.5 shrink-0 text-[#0F766E]"/><span>{enabled?'Healthify केवल सामान्य जानकारी देता है। यह निदान नहीं है और डॉक्टर की सलाह का विकल्प नहीं है.':disclaimer}</span></div>;
}
function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="block"><span className="mb-1.5 block text-sm font-semibold text-[#34534F]">{label}</span>{children}{hint && <span className="mt-1 block text-xs text-[#819690]">{hint}</span>}</label>;
}
const inputClass = 'min-h-12 w-full rounded-xl border border-[#D8E7E3] bg-[#FCFEFD] px-3.5 text-[15px] text-[#294743] placeholder:text-[#9AAEAA] focus:border-[#53A99F] focus:outline-none focus:ring-4 focus:ring-[#14B8A6]/10';
const navItems: {label:string;href:string;icon:IconComp}[] = [
  {label:'Overview',href:'/dashboard',icon:Home},{label:'Ask Healthify',href:'/ai-assistant',icon:Sparkles},
  {label:'Health reports',href:'/reports',icon:FileHeart},{label:'My family',href:'/family',icon:UsersRound},
  {label:'Find care',href:'/find-care',icon:Stethoscope},{label:'My wellness plan',href:'/my-plan',icon:Leaf},
  {label:'Meal ideas',href:'/diet',icon:Utensils},{label:'Activity',href:'/fitness',icon:Activity},
  {label:'Reminders',href:'/notifications',icon:Bell},{label:'Profile & privacy',href:'/profile',icon:UserRound},
];
function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation(); const [mobileOpen, setMobileOpen] = useState(false);
  const { user } = useUser(); const { signOut } = useClerk();
  const name = user?.firstName || 'there';
  const sidebar = <aside className="flex h-full flex-col px-4 py-5">
    <div className="mb-8 flex items-center justify-between px-2"><Logo/><button data-testid="button-close-mobile-menu" onClick={()=>setMobileOpen(false)} className="rounded-lg p-2 text-[#54716C] lg:hidden" aria-label="Close menu"><X size={20}/></button></div>
    <div className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.16em] text-[#91A8A3]">Your health space</div>
    <nav className="space-y-1" aria-label="Main navigation">{navItems.map(item => {
      const active = location === item.href || (item.href==='/family' && location.startsWith('/family/'));
      return <Link key={item.href} href={item.href} onClick={()=>setMobileOpen(false)} data-testid={`nav-${item.href.slice(1)}`} className={`flex min-h-11 items-center gap-3 rounded-xl px-3 text-[14px] font-medium transition ${active?'bg-[#DDF2ED] text-[#0F766E]':'text-[#617B76] hover:bg-[#EAF4F1] hover:text-[#285B55]'}`}><item.icon size={18} strokeWidth={active?2.4:1.9}/>{item.label}{item.label==='Reminders'&&<span className="ml-auto size-2 rounded-full bg-[#E5A658]"/>}</Link>;
    })}</nav>
    <div className="mt-auto">
      <div className="mx-1 mb-4 rounded-2xl border border-[#D7E9E4] bg-gradient-to-br from-[#F7FCFA] to-[#E7F5F1] p-4">
        <div className="mb-2 flex size-8 items-center justify-center rounded-xl bg-white text-[#0F766E]"><Heart size={16}/></div>
        <p className="text-sm font-semibold text-[#31534E]">Small steps count</p><p className="mt-1 text-xs leading-5 text-[#78918B]">A little care, built around real life.</p>
      </div>
      <button onClick={()=>signOut({redirectUrl:basePath||'/'})} data-testid="button-sign-out" className="flex min-h-11 w-full items-center gap-3 rounded-xl px-3 text-sm font-medium text-[#718984] hover:bg-white"><LogOut size={18}/>Sign out</button>
    </div>
  </aside>;
  return <div className="app-shell bg-[#F4F8F6]">
    <div className="fixed inset-y-0 left-0 z-30 hidden w-[252px] border-r border-[#E0EBE7] bg-[#F0F7F4] lg:block">{sidebar}</div>
    {mobileOpen && <div className="fixed inset-0 z-40 bg-[#173B37]/25 lg:hidden" onClick={()=>setMobileOpen(false)}><div className="h-full w-[285px] bg-[#F0F7F4] shadow-xl" onClick={e=>e.stopPropagation()}>{sidebar}</div></div>}
    <div className="min-h-[100dvh] lg:pl-[252px]">
      <header className="sticky top-0 z-20 border-b border-[#E5EEEB] bg-[#F7FAF8]/90 px-4 backdrop-blur-xl sm:px-7 lg:px-10">
        <div className="mx-auto flex h-[68px] max-w-[1320px] items-center justify-between">
          <div className="flex items-center gap-3"><button onClick={()=>setMobileOpen(true)} aria-label="Open navigation" data-testid="button-open-mobile-menu" className="rounded-xl p-2 text-[#486A64] hover:bg-white lg:hidden"><Menu size={21}/></button><div className="hidden text-sm text-[#8AA09B] sm:block">Your personal health companion</div></div>
          <div className="flex items-center gap-2 sm:gap-3"><GrandparentModeSwitch className="max-w-[180px]"/><Link href="/notifications" data-testid="link-header-notifications" className="relative rounded-xl p-2.5 text-[#65817B] hover:bg-white" aria-label="Notifications"><Bell size={19}/><span className="absolute right-2 top-2 size-1.5 rounded-full bg-[#E4A04A]"/></Link><Link href="/profile" data-testid="link-header-profile" className="flex items-center gap-2.5 rounded-full p-1 pr-2 hover:bg-white"><span className="grid size-9 place-items-center rounded-full bg-[#D7EEE8] text-sm font-bold text-[#176A61]">{name.slice(0,1)}</span><span className="hidden text-sm font-semibold text-[#42615C] sm:block">{name}</span><ChevronDown size={14} className="hidden text-[#78928C] sm:block"/></Link></div>
        </div>
      </header>
      <main className="mx-auto max-w-[1320px] px-4 pb-24 pt-7 sm:px-7 lg:px-10 lg:pb-12">{children}</main>
    </div>
    <nav className="fixed inset-x-0 bottom-0 z-20 flex justify-around border-t border-[#DEEAE6] bg-[#F8FBF9]/95 px-1 py-2 backdrop-blur lg:hidden" aria-label="Mobile navigation">{[
      navItems[0],navItems[1],navItems[3],navItems[8],navItems[9],
    ].map(it=><Link key={it.href} href={it.href} data-testid={`mobile-nav-${it.href.slice(1)}`} className={`flex min-w-14 flex-col items-center gap-1 px-2 py-1 text-[10px] font-semibold ${location===it.href?'text-[#0F766E]':'text-[#78918C]'}`}><it.icon size={20}/>{it.label==='Overview'?'Home':it.label==='Ask Healthify'?'Ask':it.label==='My family'?'Family':it.label==='Reminders'?'Reminders':'Profile'}</Link>)}</nav>
  </div>;
}
function Protected({ children }: { children: ReactNode }) {
  return <><Show when="signed-in"><AppShell>{children}</AppShell></Show><Show when="signed-out"><Redirect to="/sign-in"/></Show></>;
}
function HomeRedirect() {
  return <><Show when="signed-in"><Redirect to="/dashboard"/></Show><Show when="signed-out"><Landing/></Show></>;
}
function AuthFrame({ children }: { children: ReactNode }) {
  return <div className="soft-grid flex min-h-[100dvh] flex-col items-center justify-center bg-[#F0F7F4] px-4 py-8">
    <div className="mb-7"><Logo/></div><div className="w-full max-w-[470px] rounded-[26px] border border-[#DCEAE6] bg-white p-5 shadow-[0_18px_55px_rgba(21,72,66,.1)] sm:p-8">{children}</div>
    <p className="mt-5 flex items-center gap-1.5 text-xs text-[#78908B]"><LockKeyhole size={13}/>Your account is protected by Clerk authentication</p>
  </div>;
}
function SignInPage() { return <AuthFrame><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} forceRedirectUrl={`${basePath}/dashboard`}/></AuthFrame>; }
function SignUpPage() { return <AuthFrame><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} forceRedirectUrl={`${basePath}/dashboard`}/></AuthFrame>; }
function AliasSignIn() { return <Redirect to="/sign-in"/>; }
function AliasSignUp() { return <Redirect to="/sign-up"/>; }
function ForgotPassword() { return <Redirect to="/sign-in/forgot-password"/>; }

function Landing() {
  const health = useHealthCheck();
  return <div className="min-h-[100dvh] overflow-hidden bg-[#F5FAF8]">
    <header className="relative z-10 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-5 sm:px-8"><Logo/><nav className="hidden items-center gap-8 text-sm font-medium text-[#54736D] md:flex"><a data-testid="link-how-it-helps" href="#how-it-helps" className="hover:text-[#0F766E]">How it helps</a><a data-testid="link-care-for-everyone" href="#care-for-everyone" className="hover:text-[#0F766E]">For your whole family</a><a data-testid="link-privacy" href="#privacy" className="hover:text-[#0F766E]">Privacy first</a></nav><div className="flex items-center gap-2"><Link href="/login" data-testid="link-landing-login" className="hidden rounded-xl px-4 py-2.5 text-sm font-semibold text-[#315A54] hover:bg-white sm:inline-flex">Sign in</Link><Link href="/signup" data-testid="link-landing-signup" className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-[#0F766E] px-4 text-sm font-semibold text-white shadow-md shadow-[#0F766E]/15 hover:bg-[#115E59]">Get started <ArrowRight size={16}/></Link></div></header>
    <section className="relative mx-auto grid max-w-[1240px] items-center gap-10 px-5 pb-16 pt-9 sm:px-8 md:grid-cols-[1.05fr_.95fr] md:pb-24 md:pt-14">
      <div className="relative z-10 enter"><div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#D8EAE5] bg-white/80 px-3.5 py-2 text-xs font-semibold text-[#39766D]"><span className="size-2 rounded-full bg-[#14B8A6]"/>A calmer way to care for everyone</div>
        <h1 className="max-w-[650px] font-[Manrope] text-[44px] font-extrabold leading-[1.08] tracking-[-.065em] text-[#1F4540] sm:text-[58px] lg:text-[68px]">Your health,<br/><span className="text-[#0F766E]">all in one place.</span></h1>
        <p className="mt-6 max-w-[520px] text-[17px] leading-7 text-[#66807A]">Keep health details organized, understand reports in plain language, and make thoughtful choices for yourself and the people you care for.</p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row"><Link href="/signup" data-testid="link-hero-get-started" className="inline-flex min-h-13 items-center justify-center gap-2 rounded-xl bg-[#0F766E] px-6 font-semibold text-white shadow-lg shadow-[#0F766E]/15 hover:bg-[#115E59]">Start your health space <ArrowRight size={17}/></Link><a href="#how-it-helps" className="inline-flex min-h-13 items-center justify-center rounded-xl border border-[#D7E7E2] bg-white px-6 font-semibold text-[#42635D] hover:bg-[#F9FCFB]">See how it works</a></div>
        <div className="mt-8 flex items-center gap-3 text-sm text-[#71908A]"><ShieldCheck size={17} className="text-[#0F766E]"/><span>Private by design. Your information stays yours.</span></div>
        <div className="mt-8 flex items-center gap-2 text-xs" data-testid="status-api-connection">{health.isLoading?<LoaderCircle size={14} className="animate-spin text-[#0F766E]"/>:health.isError?<span className="size-2 rounded-full bg-[#D7A65C]"/>:<span className="size-2 rounded-full bg-[#14A88F]"/>}<span className="text-[#819791]">{health.isLoading?'Checking service status':health.isError?'Health education service status unavailable':'Health education service ready'}</span></div>
      </div>
      <div className="relative mx-auto w-full max-w-[560px]">
        <div className="absolute -right-12 -top-10 size-64 rounded-full bg-[#D6F4EB] blur-3xl"/>
        <div className="absolute -bottom-14 -left-9 size-56 rounded-full bg-[#E7F1E5] blur-3xl"/>
        <div className="relative rounded-[34px] border border-[#DCECE6] bg-gradient-to-br from-[#E6F6F0] via-[#DFF2EC] to-[#EAF4E5] p-5 shadow-[0_28px_70px_rgba(34,91,79,.12)] sm:p-7">
          <div className="absolute right-5 top-5 rounded-full border border-white/80 bg-white/70 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-[#64837C]">A little more clarity</div>
          <div className="soft-grid relative flex min-h-[370px] items-center justify-center overflow-hidden rounded-[25px] border border-white/60 bg-[#DDF1E9]/65 sm:min-h-[430px]">
            <div className="absolute left-[8%] top-[14%] grid size-16 place-items-center rounded-[22px] border border-white/80 bg-white/75 text-[#0F766E] shadow-md"><FileHeart size={27}/></div>
            <div className="absolute right-[11%] top-[26%] grid size-14 place-items-center rounded-full border border-white/80 bg-white/75 text-[#4B8B7D] shadow-md"><Heart size={23}/></div>
            <div className="absolute bottom-[14%] left-[13%] grid size-14 place-items-center rounded-full border border-white/80 bg-white/75 text-[#64886B] shadow-md"><UsersRound size={22}/></div>
            <div className="absolute bottom-[18%] right-[9%] grid size-16 place-items-center rounded-[22px] border border-white/80 bg-white/75 text-[#36877C] shadow-md"><Sparkles size={25}/></div>
            <div className="relative grid size-[188px] place-items-center rounded-full border border-white/80 bg-white/45 shadow-[0_16px_60px_rgba(41,110,96,.15)] sm:size-[218px]">
              <div className="grid size-[142px] place-items-center rounded-full bg-gradient-to-br from-[#15A79A] to-[#0F766E] text-white shadow-[0_16px_40px_rgba(15,118,110,.25)] sm:size-[166px]"><HeartPulse size={76} strokeWidth={1.4}/></div>
              <span className="absolute -right-5 top-8 size-4 rounded-full bg-[#E2B56B] ring-8 ring-white/35"/><span className="absolute -bottom-2 left-10 size-3 rounded-full bg-[#8DBBA0] ring-8 ring-white/40"/>
            </div>
            <div className="absolute bottom-5 left-5 rounded-2xl border border-white/70 bg-white/85 px-4 py-3 shadow-sm"><div className="flex items-center gap-2 text-xs font-semibold text-[#42655F]"><CheckCircle2 size={15} className="text-[#0F766E]"/> One step at a time</div><p className="mt-1 text-[10px] text-[#829791]">Your health, made easier to navigate</p></div>
          </div>
        </div>
      </div>
    </section>
    <section id="how-it-helps" className="border-y border-[#E2EEEA] bg-white/75"><div className="mx-auto grid max-w-[1240px] gap-8 px-5 py-9 sm:grid-cols-3 sm:px-8">
      {[['01','Keep it together','A clear home for health notes, reports, and reminders.'],['02','Understand more','Get a simpler explanation of health information and questions to bring to a clinician.'],['03','Care as a family','Stay organized while keeping personal information and permissions in your control.']].map(([n,t,d])=><div key={n} className="flex gap-4"><span className="font-[Manrope] text-sm font-bold text-[#62A59B]">{n}</span><div><h2 className="font-[Manrope] font-bold text-[#2A4D47]">{t}</h2><p className="mt-1 text-sm leading-6 text-[#76908A]">{d}</p></div></div>)}
    </div></section>
    <section id="care-for-everyone" className="mx-auto grid max-w-[1240px] gap-12 px-5 py-16 sm:px-8 md:grid-cols-[.85fr_1.15fr] md:py-24">
      <div><Eyebrow>Care changes through life</Eyebrow><h2 className="max-w-md font-[Manrope] text-3xl font-bold tracking-[-.05em] text-[#244641] sm:text-[42px]">A companion for every chapter.</h2><p className="mt-4 max-w-md leading-7 text-[#6D8781]">For students finding their footing, adults balancing a lot, parents caring for little ones, and older adults who value a clear, comfortable experience.</p><Link href="/signup" data-testid="link-audience-create" className="mt-6 inline-flex items-center gap-2 font-semibold text-[#0F766E]">Make room for better care <ArrowRight size={16}/></Link></div>
      <div className="grid gap-3 sm:grid-cols-2">{[
        [UserRound,'For you','A more organized view of your everyday health.'],[UsersRound,'For families','Helpful context for the people you care about.'],[Accessibility,'For every age','Readable language and accessible controls.'],[CalendarDays,'For busy days','Reminders that help you keep the little things on track.']
      ].map(([Icon,title,copy])=>{const I=Icon as IconComp;return <div key={title as string} className="rounded-[20px] border border-[#E1ECE8] bg-white p-5 shadow-[0_6px_22px_rgba(20,69,64,.035)]"><span className="mb-4 grid size-10 place-items-center rounded-xl bg-[#E8F5F1] text-[#0F766E]"><I size={20}/></span><h3 className="font-semibold text-[#34534F]">{title as string}</h3><p className="mt-1 text-sm leading-5 text-[#829791]">{copy as string}</p></div>})}</div>
    </section>
    <section id="privacy" className="bg-[#EAF5F1]"><div className="mx-auto flex max-w-[1240px] flex-col gap-8 px-5 py-12 sm:px-8 md:flex-row md:items-center md:justify-between md:py-16"><div className="flex max-w-2xl gap-4"><span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-white text-[#0F766E] shadow-sm"><ShieldCheck size={24}/></span><div><Eyebrow>Trust is part of care</Eyebrow><h2 className="font-[Manrope] text-2xl font-bold tracking-tight text-[#294C46]">Your health details deserve care, too.</h2><p className="mt-2 leading-6 text-[#66827B]">Family access is never assumed. You choose what to share, and health guidance stays educational—not a replacement for your care team.</p></div></div><Link href="/signup" data-testid="link-privacy-create" className="inline-flex min-h-12 shrink-0 items-center justify-center gap-2 rounded-xl bg-[#0F766E] px-5 font-semibold text-white hover:bg-[#115E59]">Create your account <ArrowRight size={16}/></Link></div></section>
     <footer className="mx-auto flex max-w-[1240px] flex-col gap-3 px-5 py-8 text-xs text-[#809690] sm:flex-row sm:items-center sm:justify-between sm:px-8"><Logo/><p>General health education only. Not for emergencies or diagnosis.</p><p>© {new Date().getFullYear()} Healthify</p></footer>
  </div>;
}

async function apiJson<T>(url: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(url, { credentials: "include", ...options, headers: {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  }});
  if (!response.ok) {
    let message = "Request failed";
    try { const body = await response.json(); if (typeof body?.error === "string") message = body.error; } catch {}
    throw new Error(message);
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

function Dashboard() {
  const {user}=useUser(); const first=user?.firstName||'there';
  return <><div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><Eyebrow>{new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}</Eyebrow><h1 className="font-[Manrope] text-[30px] font-bold tracking-[-.05em] text-[#23413E] sm:text-[36px]">Hello, {first}<span className="text-[#14A89A]">.</span></h1><p className="mt-2 text-[#69827D]">A clear place to pick up where you left off.</p></div><DemoTag/></div>
    <div className="grid gap-5 xl:grid-cols-[1.45fr_.8fr]">
      <div className="space-y-5">
        <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-[#0F766E] via-[#117F75] to-[#249D8C] p-6 text-white sm:p-8" testId="card-daily-check-in"><div className="absolute -right-8 -top-14 size-64 rounded-full border border-white/10"/><div className="absolute -right-2 -top-4 size-48 rounded-full border border-white/10"/><div className="relative flex flex-col justify-between gap-6 md:flex-row md:items-center"><div className="max-w-lg"><span className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5 text-[11px] font-semibold"><Sun size={14}/> Your daily check-in</span><h2 className="font-[Manrope] text-2xl font-bold tracking-tight sm:text-[28px]">How are you feeling today?</h2><p className="mt-2 text-sm leading-6 text-white/75">Take a moment to notice how you’re doing. There’s no right answer.</p></div><div className="flex gap-2" role="group" aria-label="Choose how you feel">{['A little low','Doing okay','Feeling good'].map((m,i)=><button key={m} onClick={e=>{const b=e.currentTarget;b.innerText='Saved';b.setAttribute('aria-pressed','true')}} data-testid={`button-mood-${i}`} aria-label={m} className="min-h-12 flex-1 rounded-xl border border-white/25 bg-white/10 px-3 text-xs font-semibold text-white hover:bg-white/20 sm:min-w-28">{m}</button>)}</div></div></Card>
        <div className="grid gap-4 sm:grid-cols-2">
          <Link href="/reports" data-testid="card-reports-link" className="group"><Card className="h-full transition group-hover:-translate-y-0.5 group-hover:shadow-md"><div className="flex items-start justify-between"><span className="grid size-11 place-items-center rounded-2xl bg-[#E3F4EF] text-[#0F766E]"><FileHeart size={21}/></span><ArrowRight size={17} className="text-[#9AB0AA] transition group-hover:translate-x-1 group-hover:text-[#0F766E]"/></div><h3 className="mt-5 font-[Manrope] text-lg font-bold text-[#34534F]">Understand a report</h3><p className="mt-1 text-sm leading-5 text-[#7C938E]">Get health results explained in clearer language.</p></Card></Link>
          <Link href="/ai-assistant" data-testid="card-assistant-link" className="group"><Card className="h-full transition group-hover:-translate-y-0.5 group-hover:shadow-md"><div className="flex items-start justify-between"><span className="grid size-11 place-items-center rounded-2xl bg-[#F0EAF8] text-[#76649B]"><Sparkles size={21}/></span><ArrowRight size={17} className="text-[#9AB0AA] transition group-hover:translate-x-1 group-hover:text-[#0F766E]"/></div><h3 className="mt-5 font-[Manrope] text-lg font-bold text-[#34534F]">Ask a health question</h3><p className="mt-1 text-sm leading-5 text-[#7C938E]">Explore general information, one question at a time.</p></Card></Link>
        </div>
        <Card><div className="mb-5 flex items-center justify-between"><div><Eyebrow>Coming up</Eyebrow><h2 className="font-[Manrope] text-lg font-bold text-[#34534F]">Your reminders</h2></div><Link href="/notifications" data-testid="link-see-reminders" className="text-sm font-semibold text-[#0F766E]">View all</Link></div><div className="flex items-center gap-4 rounded-2xl bg-[#F4F9F7] p-4"><span className="grid size-11 place-items-center rounded-xl bg-white text-[#58978C]"><CalendarDays size={20}/></span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="font-semibold text-[#3C5B56]">Take a moment to stretch</p><DemoTag/></div><p className="mt-1 text-xs text-[#879B96]">Today · 3:30 PM</p></div><Link href="/notifications" className="rounded-lg p-2 text-[#7E9690] hover:bg-white" aria-label="Manage reminders" data-testid="link-manage-reminders"><MoreHorizontal size={19}/></Link></div></Card>
      </div>
      <div className="space-y-5">
        <Card className="bg-[#FDFEFE]"><div className="flex items-center justify-between"><div><Eyebrow>Your week</Eyebrow><h2 className="font-[Manrope] text-lg font-bold text-[#34534F]">Gentle movement</h2></div><DemoTag/></div><div className="mt-6 flex h-32 items-end justify-between gap-2 px-2">{[39,66,48,79,56,68,43].map((v,i)=><div key={i} className="flex flex-1 flex-col items-center gap-2"><div className={`w-full max-w-8 rounded-t-lg ${i===3?'bg-[#0F766E]':'bg-[#B7DED4]'}`} style={{height:`${v}%`}}/><span className="text-[10px] text-[#90A49F]">{['M','T','W','T','F','S','S'][i]}</span></div>)}</div><div className="mt-4 flex items-center justify-between border-t border-[#EAF0EE] pt-4"><span className="text-sm text-[#708982]">Movement minutes</span><span className="font-[Manrope] text-lg font-bold text-[#315852]">126 <span className="text-xs font-medium text-[#90A49F]">this week</span></span></div><p className="mt-3 text-[11px] leading-4 text-[#8AA09A]">Sample activity only — not connected to a wearable.</p></Card>
        <Card><div className="mb-4 flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-[#F1F4E8] text-[#73884F]"><Leaf size={20}/></span><div><Eyebrow>One gentle nudge</Eyebrow><h2 className="font-semibold text-[#3B5A53]">Make space to unwind</h2></div></div><p className="text-sm leading-6 text-[#78918B]">A few slower breaths between tasks can create a small moment of calm.</p><Link href="/my-plan" data-testid="link-wellness-nudge" className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-[#0F766E]">Build a wellness plan <ArrowRight size={15}/></Link></Card>
      </div>
    </div><Disclaimer/>
  </>;
}

type ChatMessage = {role:'user'|'assistant';content:string;urgent?:boolean;safetyNote?:string|null};
function Assistant() {
  const sendChat=useSendHealthChat(); const [messages,setMessages]=useState<ChatMessage[]>([{role:'assistant',content:'Hi, I’m here to help you explore general health information. What would you like to understand today?'}]); const [draft,setDraft]=useState(''); const [voiceHelp,setVoiceHelp]=useState('');
  const endRef=useRef<HTMLDivElement>(null); useEffect(()=>{endRef.current?.scrollIntoView({behavior:'smooth'})},[messages]);
  const submit=(e?:FormEvent)=>{e?.preventDefault();const message=draft.trim();if(!message||sendChat.isPending)return;const history=messages.slice(-10).map(({role,content})=>({role,content}));setMessages(m=>[...m,{role:'user',content:message}]);setDraft('');sendChat.mutate({data:{message,history}},{onSuccess:r=>setMessages(m=>[...m,{role:'assistant',content:r.answer,urgent:r.urgent,safetyNote:r.safetyNote}]),onError:()=>setMessages(m=>[...m,{role:'assistant',content:'I couldn’t reach the health education service just now. Please try again in a moment, or speak with a healthcare professional for personal guidance.'}])});};
   const voice=()=>{const Speech=(window as Window & {SpeechRecognition?:new()=>any}).SpeechRecognition||(window as Window & {webkitSpeechRecognition?:new()=>any}).webkitSpeechRecognition;if(!Speech){setVoiceHelp('Voice input is not available in this browser. You can type your question instead.');return;}const recognition=new Speech();recognition.lang=navigator.language||'en-US';recognition.onresult=(event:any)=>{setDraft(event.results[0][0].transcript);setVoiceHelp('Your words are ready to review before sending.')};recognition.onerror=()=>setVoiceHelp('We couldn’t hear that clearly. Please try again or type your question.');recognition.start();setVoiceHelp('Listening… speak your question when you’re ready.');};
  const speak=(text:string)=>{if(!('speechSynthesis'in window)){setVoiceHelp('Spoken playback is not supported in this browser.');return;}window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(text);utterance.lang=navigator.language||'en-US';window.speechSynthesis.speak(utterance);};
  return <><PageTitle eyebrow="Health education" title="Ask Healthify" text="A thoughtful place to explore general health questions—without replacing advice from a clinician."/><div className="grid gap-5 xl:grid-cols-[1fr_300px]"><Card className="flex min-h-[560px] flex-col p-0" testId="panel-health-chat"><div className="flex items-center gap-3 border-b border-[#E6EFEC] px-5 py-4"><div className="grid size-10 place-items-center rounded-xl bg-[#E5F4EF] text-[#0F766E]"><Sparkles size={20}/></div><div><div className="font-semibold text-[#34534F]">Healthify assistant</div><div className="flex items-center gap-1.5 text-xs text-[#849A94]"><span className="size-1.5 rounded-full bg-[#14B8A6]"/>General health education</div></div></div>
    <div className="flex-1 space-y-4 overflow-y-auto px-4 py-5 sm:px-6" aria-live="polite">{messages.map((m,i)=><div key={i} data-testid={`chat-message-${i}`} className={`flex ${m.role==='user'?'justify-end':'justify-start'}`}><div className={`max-w-[88%] rounded-2xl px-4 py-3 text-sm leading-6 ${m.role==='user'?'rounded-br-md bg-[#0F766E] text-white':'rounded-bl-md border border-[#E3ECE9] bg-[#F5FAF8] text-[#49635E]'}`}>{m.urgent&&<div className="mb-2 flex items-center gap-2 rounded-lg bg-[#FFF0EB] p-2 text-xs font-bold text-[#9C493E]"><AlertTriangle size={15}/>Urgent care may be needed</div>}{m.content}{m.safetyNote&&<p className="mt-2 border-t border-[#DBE8E4] pt-2 text-xs">{m.safetyNote}</p>}{m.role==='assistant'&&<button aria-label="Play answer aloud" onClick={()=>speak(m.content)} data-testid={`button-speak-answer-${i}`} className="mt-2 flex items-center gap-1 text-xs font-semibold text-[#0F766E]"><Volume2 size={14}/>Listen</button>}</div></div>)}{sendChat.isPending&&<div className="flex gap-2 rounded-2xl bg-[#F5FAF8] px-4 py-3 text-sm text-[#78918B]" data-testid="status-chat-loading"><LoaderCircle size={17} className="animate-spin"/>Putting together a careful response…</div>}<div ref={endRef}/></div>
    {voiceHelp&&<p data-testid="text-voice-status" role="status" className="mx-5 mb-2 text-xs text-[#68827C]">{voiceHelp}</p>}
    <form onSubmit={submit} className="border-t border-[#E6EFEC] p-4 sm:p-5"><div className="flex items-end gap-2"><textarea aria-label="Your health question" data-testid="input-health-question" value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();submit()}}} placeholder="Ask a general health question…" maxLength={3000} rows={2} className={`${inputClass} min-h-[54px] resize-none py-3`}/><button type="button" onClick={voice} data-testid="button-voice-input" aria-label="Use voice input" className="grid size-12 shrink-0 place-items-center rounded-xl border border-[#D8E7E3] text-[#0F766E] hover:bg-[#EDF8F4]"><Mic size={19}/></button><Button type="submit" testId="button-send-question" disabled={!draft.trim()||sendChat.isPending} className="size-12 min-h-12 shrink-0 px-0" aria-label="Send question"><Send size={18}/></Button></div><p className="mt-2 text-[11px] text-[#90A49F]">Enter to send · Shift + Enter for a new line · Avoid sharing identifying details.</p></form>
  </Card><div className="space-y-5"><Card><Eyebrow>Try asking</Eyebrow><h3 className="font-semibold text-[#365751]">Start with a question</h3><div className="mt-3 space-y-2">{['What can help me build a consistent sleep routine?','What does a balanced breakfast include?','How can I prepare for a check-up?'].map((q,i)=><button key={q} onClick={()=>setDraft(q)} data-testid={`button-suggested-question-${i}`} className="w-full rounded-xl border border-[#E5EEEB] bg-[#FBFDFC] p-3 text-left text-sm leading-5 text-[#5E7973] hover:border-[#BFDCD5] hover:bg-[#F2F9F6]">{q}</button>)}</div></Card><Card className="border-[#E9E7D9] bg-[#FFFEF8]"><div className="flex gap-2"><Info size={17} className="mt-0.5 shrink-0 text-[#A17B37]"/><div><h3 className="text-sm font-semibold text-[#5A5848]">When symptoms feel urgent</h3><p className="mt-2 text-xs leading-5 text-[#777666]">If you may be in immediate danger or have severe, sudden symptoms, contact local emergency services now. Don’t wait for an online response.</p></div></div></Card></div></div><Disclaimer/></>;
}

function Reports() {
  const analyze=useAnalyzeHealthReport();const [file,setFile]=useState<File|null>(null);const [error,setError]=useState('');
  const choose=async(f:File|null)=>{setError('');if(!f)return;if(!['application/pdf','image/jpeg','image/png'].includes(f.type)){setError('Choose a PDF, JPEG, or PNG file.');return;}if(f.size>5_200_000){setError('This file is too large for a secure analysis request. Choose a file smaller than 5 MB.');return;}setFile(f);};
  const submit=async()=>{if(!file)return;try{const data=await file.arrayBuffer();const b64=btoa(Array.from(new Uint8Array(data),b=>String.fromCharCode(b)).join(''));const mediaType=file.type as ReportAnalysisInput['mediaType'];analyze.mutate({data:{fileName:file.name,mediaType,dataBase64:b64}});}catch{setError('We couldn’t read this file. Please try another copy.');}};
  const result=analyze.data;
  return <><PageTitle eyebrow="Your records" title="Health reports" text="Get a plain-language explanation of a report and a few questions you may want to bring to your clinician."/><div className="grid gap-5 xl:grid-cols-[.85fr_1.15fr]"><Card className="h-fit"><div className="mb-5 flex items-center gap-3"><span className="grid size-11 place-items-center rounded-2xl bg-[#E4F4EF] text-[#0F766E]"><FileHeart size={21}/></span><div><h2 className="font-[Manrope] text-lg font-bold text-[#355550]">Explain a report</h2><p className="text-xs text-[#839994]">Files are used for this request only.</p></div></div>
    <label data-testid="input-report-file-wrap" className="flex min-h-48 cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-[#C9DFD9] bg-[#F7FBF9] px-5 text-center transition hover:border-[#65B5A9] hover:bg-[#F0F9F6]"><Upload size={25} className="mb-3 text-[#329084]"/><span className="font-semibold text-[#45635D]">{file?file.name:'Choose a report to upload'}</span><span className="mt-1 text-xs text-[#8A9E99]">PDF, JPEG, PNG · up to 5 MB</span><input type="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" onChange={e=>choose(e.target.files?.[0]||null)} data-testid="input-report-file" className="sr-only"/></label>
    <div className="mt-4 flex items-start gap-2 rounded-xl bg-[#F5F8F4] p-3 text-xs leading-5 text-[#768D82]"><LockKeyhole size={15} className="mt-0.5 shrink-0 text-[#6F977F]"/>Your report is sent for this analysis request and is not saved to your Healthify account.</div>
    {error&&<p role="alert" data-testid="text-report-error" className="mt-3 rounded-xl bg-[#FFF1EF] p-3 text-sm text-[#9B433B]">{error}</p>}{analyze.isError&&<p role="alert" data-testid="text-report-api-error" className="mt-3 text-sm text-[#9B433B]">We couldn’t explain this report right now. Please try again later.</p>}
    <Button onClick={submit} disabled={!file||analyze.isPending} testId="button-analyze-report" className="mt-4 w-full">{analyze.isPending?<><LoaderCircle size={16} className="animate-spin"/>Reading report…</>:<>Explain this report <ArrowRight size={16}/></>}</Button>
    <p className="mt-3 text-[11px] leading-5 text-[#8B9C96]">Do not upload someone else’s report without their permission. This tool does not diagnose.</p></Card>
    <div className="space-y-5">{analyze.isPending?<Card><div className="animate-pulse space-y-4"><div className="h-5 w-1/3 rounded bg-[#E5EFEB]"/><div className="h-3 w-full rounded bg-[#EDF3F1]"/><div className="h-3 w-4/5 rounded bg-[#EDF3F1]"/><div className="h-24 rounded-xl bg-[#EDF3F1]"/></div></Card>:result?<><Card data-testid="panel-report-result"><Eyebrow>Plain-language overview</Eyebrow><h2 className="font-[Manrope] text-xl font-bold text-[#355550]">A simpler explanation</h2><p className="mt-3 leading-7 text-[#5F7872]">{result.summary}</p><div className="mt-4 rounded-xl bg-[#F1F8F5] p-4 text-sm leading-6 text-[#56726B]">{result.simpleExplanation}</div></Card><Card><Eyebrow>Values in this report</Eyebrow><div className="space-y-3">{result.values.map((v,i)=><div key={i} data-testid={`report-value-${i}`} className="rounded-xl border border-[#E7EFEC] p-4"><div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-semibold text-[#395A54]">{v.testName}</h3><span className="rounded-lg bg-[#EEF7F4] px-2.5 py-1 text-sm font-bold text-[#27776D]">{v.value}</span></div><p className="mt-2 text-sm leading-5 text-[#708882]">{v.explanation}</p>{v.referenceRange&&<p className="mt-2 text-xs text-[#91A49F]">Reference range: {v.referenceRange}</p>}<p className="mt-2 text-xs font-medium text-[#56736C]">{v.generalInterpretation}</p></div>)}</div></Card><Card><Eyebrow>For your next conversation</Eyebrow><h3 className="font-semibold text-[#355550]">Questions you might ask</h3><ul className="mt-3 space-y-2">{result.questionsForDoctor.map((q,i)=><li key={i} className="flex gap-2 text-sm leading-5 text-[#607B75]"><span className="text-[#0F766E]">•</span>{q}</li>)}</ul><Disclaimer/><p className="mt-3 text-xs leading-5 text-[#839790]">{result.disclaimer}</p></Card></>:<Card className="flex min-h-[400px] flex-col items-center justify-center text-center"><span className="grid size-16 place-items-center rounded-[22px] bg-[#EAF6F2] text-[#48988C]"><FileText size={29}/></span><h2 className="mt-4 font-[Manrope] text-xl font-bold text-[#385851]">Your explanation will appear here</h2><p className="mt-2 max-w-sm text-sm leading-6 text-[#829791]">Choose a report when you’re ready. You can review its explanation before deciding what to discuss with your care team.</p></Card>}</div></div><Disclaimer/></>;
}

function Family() {
  type Member={id:string;name:string;relation:string;age?:number;permission:'View'|'Edit'|'No access'};
  const [members,setMembers]=useState<Member[]>([]); const [name,setName]=useState(''); const [relation,setRelation]=useState(''); const [age,setAge]=useState('');
  const [loading,setLoading]=useState(true); const [error,setError]=useState('');
  const load=useCallback(async()=>{try{setLoading(true);setMembers(await apiJson<Member[]>('/api/data/family'));}catch{setError('We couldn’t load your family list. Check that MongoDB is configured.');}finally{setLoading(false);}},[]);
  useEffect(()=>{void load();},[load]);
  const add=async(e:FormEvent)=>{e.preventDefault();if(!name.trim()||!relation.trim())return;try{const m=await apiJson<Member>('/api/data/family',{method:'POST',body:JSON.stringify({name:name.trim(),relation:relation.trim(),age:age?Number(age):undefined})});setMembers(v=>[...v,m]);setName('');setRelation('');setAge('');}catch{setError('We couldn’t add this family member.');}};
  const permission=async(id:string,p:Member['permission'])=>{try{const m=await apiJson<Member>(`/api/data/family/${id}`,{method:'PATCH',body:JSON.stringify({permission:p})});setMembers(v=>v.map(x=>x.id===id?m:x));}catch{setError('We couldn’t update access.');}};
  const remove=async(id:string)=>{try{await apiJson<void>(`/api/data/family/${id}`,{method:'DELETE'});setMembers(v=>v.filter(x=>x.id!==id));}catch{setError('We couldn’t remove this family member.');}};
  return <><PageTitle eyebrow="Your people" title="My family" text="Family members are stored privately under your account. Access starts at “No access” until you choose otherwise."/>
    <div className="grid gap-5 xl:grid-cols-[.75fr_1.25fr]">
      <Card className="h-fit"><h2 className="mb-1 font-[Manrope] text-lg font-bold text-[#365650]">Add a family member</h2><p className="mb-5 text-sm text-[#849892]">Only the account owner can change access.</p>
      <form onSubmit={add} className="space-y-4"><Field label="Name"><input value={name} onChange={e=>setName(e.target.value)} maxLength={100} className={inputClass} placeholder="Full name"/></Field><Field label="Relationship"><input value={relation} onChange={e=>setRelation(e.target.value)} maxLength={60} className={inputClass} placeholder="e.g. Mother"/></Field><Field label="Age (optional)"><input type="number" min="0" max="120" value={age} onChange={e=>setAge(e.target.value)} className={inputClass}/></Field><Button type="submit" disabled={!name.trim()||!relation.trim()} className="w-full"><Plus size={16}/>Add member</Button></form></Card>
      <Card><div className="mb-5 flex items-center justify-between"><div><Eyebrow>Private by default</Eyebrow><h2 className="font-[Manrope] text-lg font-bold text-[#365650]">Family members</h2></div><span className="rounded-full bg-[#EAF6F2] px-3 py-1 text-xs font-bold text-[#367C72]">{members.length}</span></div>
      {error&&<p role="alert" className="mb-3 rounded-xl bg-[#FFF1EF] p-3 text-sm text-[#9B433B]">{error}</p>}
      {loading?<p className="text-sm text-[#80958F]">Loading family…</p>:members.length===0?<p className="rounded-2xl bg-[#F5F9F7] p-5 text-sm text-[#78918B]">No family members added yet.</p>:
      <div className="grid gap-4 md:grid-cols-2">{members.map((m,i)=><div key={m.id} className="rounded-2xl border border-[#E5EEEB] p-4"><div className="flex items-start justify-between"><span className="grid size-12 place-items-center rounded-[18px] bg-[#EAF5F1] font-bold text-[#42635D]">{m.name.split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase()}</span><button onClick={()=>void remove(m.id)} aria-label={`Remove ${m.name}`} className="text-[#9AABA6] hover:text-[#AB4D45]"><Trash2 size={16}/></button></div><h3 className="mt-4 font-[Manrope] font-bold text-[#34534F]">{m.name}</h3><p className="mt-1 text-sm text-[#839791]">{m.relation}{m.age!==undefined?` · age ${m.age}`:''}</p><div className="mt-4 grid grid-cols-3 gap-1.5">{(['View','Edit','No access'] as const).map(p=><button key={p} onClick={()=>void permission(m.id,p)} className={`min-h-10 rounded-lg border px-1 text-[11px] font-semibold ${m.permission===p?'border-[#0F766E] bg-[#E9F6F2] text-[#0F766E]':'border-[#E0EAE7] text-[#6D8580]'}`}>{p}</button>)}</div></div>)}</div>}</Card></div><Disclaimer/></>;
}

function FindCare() {
  type Provider={id:string;name:string;address:string;latitude:number|null;longitude:number|null;mapsUrl:string|null};
  const [query,setQuery]=useState(''); const [location,setLocation]=useState(''); const [providers,setProviders]=useState<Provider[]>([]);
  const [loading,setLoading]=useState(false); const [searched,setSearched]=useState(false); const [error,setError]=useState('');
  const search=async(e:FormEvent)=>{e.preventDefault();if(!query.trim()||!location.trim())return;setLoading(true);setSearched(true);setError('');
    try{const params=new URLSearchParams({query:query.trim(),location:location.trim()});const result=await apiJson<{providers:Provider[]}>(`/api/care/search?${params.toString()}`);setProviders(result.providers);}
    catch(err){setProviders([]);setError(err instanceof Error?err.message:'We couldn’t search for care right now.');}finally{setLoading(false);}
  };
  return <><PageTitle eyebrow="Care near you" title="Find care" text="Search verified place results without inventing provider names, ratings, or availability."/>
    <Card className="mb-5"><form onSubmit={search} className="grid gap-3 md:grid-cols-[1fr_1fr_auto]"><Field label="What kind of care?"><div className="relative"><Search size={17} className="absolute left-3.5 top-4 text-[#87A099]"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="e.g. primary care, dental" aria-label="Type of care" className={`${inputClass} pl-10`}/></div></Field>
    <Field label="Location"><input value={location} onChange={e=>setLocation(e.target.value)} placeholder="City or postal code" aria-label="Care location" className={inputClass}/></Field>
    <Button type="submit" disabled={loading||!query.trim()||!location.trim()} className="self-end">{loading?<><LoaderCircle size={17} className="animate-spin"/>Searching…</>:<><Search size={17}/>Search</>}</Button></form></Card>
    {error&&<div role="alert" className="mb-5 rounded-xl bg-[#FFF1EF] p-4 text-sm text-[#9B433B]">{error}</div>}
    {searched&&providers.length>0?<div className="grid gap-4 md:grid-cols-2">{providers.map(p=><Card key={p.id}><div className="flex items-start gap-3"><span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-[#EAF5F1] text-[#488D83]"><Stethoscope size={21}/></span><div className="min-w-0"><h2 className="font-[Manrope] font-bold text-[#34534F]">{p.name}</h2><p className="mt-1 text-sm leading-5 text-[#7C938D]">{p.address}</p>{p.mapsUrl&&<a href={p.mapsUrl} target="_blank" rel="noreferrer" className="mt-3 inline-flex text-sm font-semibold text-[#0F766E]">Open in Google Maps <ArrowRight size={15}/></a>}</div></div><p className="mt-4 text-xs leading-5 text-[#8A9E99]">This result comes from Google Places. Healthify does not verify clinical quality, pricing, appointments, or emergency availability.</p></Card>)}</div>
    :<Card className="flex min-h-[310px] flex-col items-center justify-center text-center"><span className="grid size-16 place-items-center rounded-[22px] bg-[#EAF5F1] text-[#488D83]"><Stethoscope size={29}/></span><h2 className="mt-4 font-[Manrope] text-xl font-bold text-[#34534F]">{searched?(error?'Care search unavailable':'No matching providers found'):'Search for care near you'}</h2><p className="mt-2 max-w-lg text-sm leading-6 text-[#7C938D]">{searched&&!error?'Try a broader care type or a nearby city.':'Enter a care type and location to see live Google Places results.'}</p><div className="mt-5 rounded-xl bg-[#F5F8F5] px-4 py-3 text-left text-xs leading-5 text-[#71867B]"><Info size={15} className="mr-2 inline text-[#81935A]"/>If you need urgent help, contact local emergency services. This search is not an emergency service.</div></Card>}
    <Disclaimer/></>;
}

function WellnessPlan() {
 const plan=useGenerateWellnessPlan();const [age,setAge]=useState('');const [activity,setActivity]=useState<WellnessPlanInput['activityLevel']>('moderate');const [dietPreference,setDietPreference]=useState('No preference');const [goal,setGoal]=useState('Feel more balanced day to day');const [sleep,setSleep]=useState('');const [allergies,setAllergies]=useState('');const icons:Record<string,IconComp>={nutrition:Salad,movement:Activity,sleep:Moon,hydration:Droplets,stress:Wind};
 const submit=(e:FormEvent)=>{e.preventDefault();const payload:WellnessPlanInput={activityLevel:activity,dietPreference,goal,allergies:allergies.split(',').map(a=>a.trim()).filter(Boolean)};if(age)payload.age=Number(age);if(sleep)payload.sleepHours=Number(sleep);plan.mutate({data:payload});};
 return <><PageTitle eyebrow="Your everyday wellbeing" title="My wellness plan" text="Explore general suggestions based on what matters to you. Keep what feels helpful; leave what doesn’t."/><div className="grid gap-5 xl:grid-cols-[.82fr_1.18fr]"><Card className="h-fit"><h2 className="mb-5 font-[Manrope] text-lg font-bold text-[#365650]">A little about you</h2><form onSubmit={submit} className="space-y-4"><Field label="Your goal"><input value={goal} onChange={e=>setGoal(e.target.value)} maxLength={120} className={inputClass} data-testid="input-plan-goal"/></Field><Field label="Activity level"><select value={activity} onChange={e=>setActivity(e.target.value as WellnessPlanInput['activityLevel'])} className={inputClass} data-testid="select-activity-level"><option value="low">A little movement</option><option value="moderate">Some movement most weeks</option><option value="active">Active most days</option><option value="not-specified">Prefer not to say</option></select></Field><Field label="Diet preference"><input value={dietPreference} onChange={e=>setDietPreference(e.target.value)} className={inputClass} data-testid="input-diet-preference"/></Field><div className="grid grid-cols-2 gap-3"><Field label="Age (optional)"><input type="number" min="13" max="120" value={age} onChange={e=>setAge(e.target.value)} placeholder="Age" className={inputClass} data-testid="input-plan-age"/></Field><Field label="Sleep hours (optional)"><input type="number" min="0" max="24" step=".5" value={sleep} onChange={e=>setSleep(e.target.value)} placeholder="Hours" className={inputClass} data-testid="input-plan-sleep"/></Field></div><Field label="Allergies (optional)" hint="Separate items with commas"><input value={allergies} onChange={e=>setAllergies(e.target.value)} placeholder="e.g. peanuts" className={inputClass} data-testid="input-plan-allergies"/></Field><Button type="submit" testId="button-generate-plan" disabled={plan.isPending} className="w-full">{plan.isPending?<><LoaderCircle size={16} className="animate-spin"/>Thinking…</>:<><Sparkles size={16}/>Create my suggestions</>}</Button></form></Card><div className="space-y-5">{plan.isError&&<div role="alert" data-testid="status-plan-error" className="rounded-xl bg-[#FFF1EF] p-4 text-sm text-[#9B433B]">We couldn’t create suggestions right now. Please check your connection and try again.</div>}{plan.isPending?<Card className="animate-pulse space-y-4"><div className="h-5 w-1/3 rounded bg-[#E5EFEB]"/>{[1,2,3].map(x=><div key={x} className="h-20 rounded-xl bg-[#F0F5F3]"/> )}</Card>:plan.data?<><Card><Eyebrow>Ideas for your day</Eyebrow><h2 className="font-[Manrope] text-xl font-bold text-[#355550]">Your thoughtful starting points</h2><div className="mt-5 space-y-3">{plan.data.suggestions.map((s,i)=>{const I=icons[s.category]||Heart;return <div key={i} data-testid={`wellness-suggestion-${i}`} className="flex gap-4 rounded-2xl border border-[#E5EEEB] p-4"><span className="grid size-10 shrink-0 place-items-center rounded-xl bg-[#E8F5F0] text-[#218276]"><I size={19}/></span><div><div className="text-[10px] font-bold uppercase tracking-[.12em] text-[#81A098]">{s.category}</div><p className="mt-1 font-semibold text-[#3C5B55]">{s.suggestion}</p><p className="mt-1 text-sm leading-5 text-[#7B918C]">{s.why}</p></div></div>})}</div><p className="mt-4 text-xs leading-5 text-[#81968F]">{plan.data.disclaimer}</p></Card><Disclaimer/></>:<Card className="flex min-h-[430px] flex-col items-center justify-center text-center"><span className="grid size-16 place-items-center rounded-[22px] bg-[#EAF6F2] text-[#55998E]"><Leaf size={28}/></span><h2 className="mt-4 font-[Manrope] text-xl font-bold text-[#355550]">Your plan starts with you</h2><p className="mt-2 max-w-sm text-sm leading-6 text-[#819690]">Share a little about your routine and we’ll offer general, flexible ideas for wellbeing.</p></Card>}</div></div><Disclaimer/></>;
}

function Diet() {
 const diet=useGenerateDietPlan();const [dietType,setDietType]=useState<DietPlanInput['dietType']>('vegetarian');const [cuisine,setCuisine]=useState('Any cuisine');const [allergies,setAllergies]=useState('');const [budget,setBudget]=useState<DietPlanInput['budget']>('moderate');const [goal,setGoal]=useState('Balanced everyday meals');const [meals,setMeals]=useState('3');const [condition,setCondition]=useState('');
 const submit=(e:FormEvent)=>{e.preventDefault();const data:DietPlanInput={dietType,cuisine,allergies:allergies.split(',').map(s=>s.trim()).filter(Boolean),budget,goal,mealsPerDay:Number(meals)};if(condition)data.medicalCondition=condition;diet.mutate({data});};
 return <><PageTitle eyebrow="Food that fits real life" title="Balanced meal ideas" text="Explore flexible meal inspiration based on your preferences. These are ideas, not medical nutrition advice."/><div className="grid gap-5 xl:grid-cols-[.8fr_1.2fr]"><Card className="h-fit"><h2 className="mb-5 font-[Manrope] text-lg font-bold text-[#365650]">Shape your suggestions</h2><form onSubmit={submit} className="space-y-4"><Field label="Eating style"><select value={dietType} onChange={e=>setDietType(e.target.value as DietPlanInput['dietType'])} className={inputClass} data-testid="select-diet-type"><option value="vegetarian">Vegetarian</option><option value="non-vegetarian">Includes meat or fish</option><option value="vegan">Vegan</option></select></Field><Field label="Cuisine"><input value={cuisine} onChange={e=>setCuisine(e.target.value)} maxLength={80} className={inputClass} data-testid="input-cuisine"/></Field><Field label="Allergies or foods to avoid" hint="Separate items with commas"><input value={allergies} onChange={e=>setAllergies(e.target.value)} placeholder="e.g. tree nuts" className={inputClass} data-testid="input-diet-allergies"/></Field><div className="grid grid-cols-2 gap-3"><Field label="Budget"><select value={budget} onChange={e=>setBudget(e.target.value as DietPlanInput['budget'])} className={inputClass} data-testid="select-budget"><option value="budget">Budget-friendly</option><option value="moderate">Moderate</option><option value="flexible">Flexible</option></select></Field><Field label="Meals per day"><select value={meals} onChange={e=>setMeals(e.target.value)} className={inputClass} data-testid="select-meals-per-day">{[1,2,3,4].map(n=><option key={n} value={n}>{n}</option>)}</select></Field></div><Field label="Your goal"><input value={goal} onChange={e=>setGoal(e.target.value)} maxLength={120} className={inputClass} data-testid="input-diet-goal"/></Field><Field label="Health considerations (optional)" hint="For context only; consult a qualified professional"><input value={condition} onChange={e=>setCondition(e.target.value)} maxLength={200} className={inputClass} data-testid="input-medical-condition"/></Field><Button type="submit" testId="button-generate-meals" disabled={diet.isPending} className="w-full">{diet.isPending?<><LoaderCircle size={16} className="animate-spin"/>Finding ideas…</>:<><Utensils size={16}/>Suggest meals</>}</Button></form></Card><div className="space-y-5">{diet.isError&&<div role="alert" data-testid="status-diet-error" className="rounded-xl bg-[#FFF1EF] p-4 text-sm text-[#9B433B]">Meal ideas aren’t available right now. Please try again shortly.</div>}{diet.isPending?<Card className="animate-pulse space-y-4"><div className="h-5 w-1/3 rounded bg-[#E5EFEB]"/>{[1,2,3].map(n=><div key={n} className="h-28 rounded-xl bg-[#F0F5F3]"/> )}</Card>:diet.data?<Card><Eyebrow>A few balanced ideas</Eyebrow><h2 className="font-[Manrope] text-xl font-bold text-[#355550]">Ideas to make your own</h2><div className="mt-5 space-y-3">{diet.data.meals.map((meal,i)=><article key={i} data-testid={`meal-card-${i}`} className="rounded-2xl border border-[#E4EEEA] p-4 sm:p-5"><div className="flex flex-wrap items-start justify-between gap-2"><div><span className="rounded-full bg-[#EAF6F2] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#347D73]">{meal.meal}</span><h3 className="mt-2 font-[Manrope] text-lg font-bold text-[#3B5B54]">{meal.name}</h3></div><span className="flex items-center gap-1 text-xs text-[#80958F]"><Clock3 size={14}/>{meal.preparationMinutes} min</span></div><p className="mt-3 text-sm leading-5 text-[#687F79]"><span className="font-semibold">Ingredients: </span>{meal.ingredients.join(', ')}</p><p className="mt-2 text-xs leading-5 text-[#869A94]">{meal.nutritionNote}</p></article>)}</div><p className="mt-4 text-xs leading-5 text-[#81968F]">{diet.data.disclaimer}</p></Card>:<Card className="flex min-h-[430px] flex-col items-center justify-center text-center"><span className="grid size-16 place-items-center rounded-[22px] bg-[#F1F5E8] text-[#839354]"><Salad size={28}/></span><h2 className="mt-4 font-[Manrope] text-xl font-bold text-[#355550]">A meal idea can start simply</h2><p className="mt-2 max-w-sm text-sm leading-6 text-[#819690]">Set your preferences and get approachable meal inspiration that you can adapt to your own needs.</p></Card>}</div></div><Disclaimer/></>;
}

const weekData=[{day:'Mon',steps:6342,sleep:7.1},{day:'Tue',steps:7821,sleep:6.8},{day:'Wed',steps:5904,sleep:7.6},{day:'Thu',steps:8916,sleep:7.2},{day:'Fri',steps:7238,sleep:6.5},{day:'Sat',steps:10344,sleep:8.1},{day:'Sun',steps:6841,sleep:7.4}];
function Fitness() {
  return <><PageTitle eyebrow="Movement & rest" title="Activity" text="A gentle overview of sample wearable information. Nothing here is connected to a device or your actual health records." action={<DemoTag/>}/><div className="mb-5 rounded-2xl border border-[#E9E5D5] bg-[#FFFEF8] p-4 text-sm leading-6 text-[#786F55]"><Watch size={16} className="mr-2 inline"/>These sample values are DEMO DATA, not measurements from you or a real wearable.</div><div className="grid gap-5 xl:grid-cols-[1.3fr_.7fr]"><Card><div className="mb-4 flex items-start justify-between"><div><Eyebrow>This week</Eyebrow><h2 className="font-[Manrope] text-lg font-bold text-[#365650]">Everyday movement</h2></div><DemoTag/></div><div className="h-[270px] w-full" data-testid="chart-weekly-activity"><ResponsiveActivity/></div><div className="mt-2 flex flex-wrap items-center gap-5 text-xs text-[#80958F]"><span className="flex items-center gap-2"><span className="size-2.5 rounded-sm bg-[#0F766E]"/>Steps</span><span>Sample values · no wearable connection</span></div></Card><div className="space-y-5"><Card><div className="flex items-start justify-between"><span className="grid size-10 place-items-center rounded-xl bg-[#E9F5F1] text-[#32877C]"><Activity size={20}/></span><DemoTag/></div><Eyebrow>Daily average</Eyebrow><div className="font-[Manrope] text-3xl font-bold text-[#31564F]">7,629 <span className="text-sm font-semibold text-[#839790]">steps</span></div><p className="mt-2 text-xs text-[#889C96]">Sample across the last seven days</p></Card><Card><div className="flex items-start justify-between"><span className="grid size-10 place-items-center rounded-xl bg-[#F1EFF8] text-[#766C98]"><Moon size={20}/></span><DemoTag/></div><Eyebrow>Rest overview</Eyebrow><div className="font-[Manrope] text-3xl font-bold text-[#31564F]">7.2 <span className="text-sm font-semibold text-[#839790]">hours</span></div><p className="mt-2 text-xs text-[#889C96]">Sample nightly average</p></Card></div></div><Card className="mt-5"><div className="mb-4 flex items-center justify-between"><div><Eyebrow>One week at a glance</Eyebrow><h2 className="font-[Manrope] text-lg font-bold text-[#365650]">Your daily samples</h2></div><DemoTag/></div><div className="overflow-x-auto"><table className="w-full min-w-[520px] text-left text-sm"><thead><tr className="border-b border-[#E7EFEC] text-xs text-[#8AA09A]"><th className="pb-3 font-medium">Day</th><th className="pb-3 font-medium">Steps</th><th className="pb-3 font-medium">Sleep</th><th className="pb-3 font-medium">Source</th></tr></thead><tbody>{weekData.map(d=><tr key={d.day} className="border-b border-[#F0F4F2] last:border-0" data-testid={`row-fitness-${d.day.toLowerCase()}`}><td className="py-3.5 font-semibold text-[#49655F]">{d.day}</td><td className="py-3.5 text-[#5C7771]">{d.steps.toLocaleString()}</td><td className="py-3.5 text-[#5C7771]">{d.sleep} hrs</td><td className="py-3.5 text-xs text-[#9AAEA8]">Demo sample</td></tr>)}</tbody></table></div></Card><Disclaimer/></>;
}
function ResponsiveActivity() {
  return <ResponsiveContainer width="100%" height="100%"><BarChart data={weekData} margin={{top:12,right:12,left:-18,bottom:0}}><CartesianGrid stroke="#E9F0ED" vertical={false}/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill:'#829790',fontSize:12}}/><YAxis axisLine={false} tickLine={false} tick={{fill:'#9AAEA8',fontSize:11}}/><Tooltip cursor={{fill:'#EAF5F1'}} contentStyle={{border:'1px solid #DCEAE6',borderRadius:12,boxShadow:'0 8px 25px #17433b10'}}/><Bar dataKey="steps" fill="#53A99B" radius={[7,7,0,0]} maxBarSize={34}/></BarChart></ResponsiveContainer>;
}

type Reminder={id:number;title:string;date:string;time:string;enabled:boolean};
function Notifications() {
  type Reminder = {id:string; title:string; dateLabel:string; time:string; enabled:boolean};
  const [items,setItems]=useState<Reminder[]>([]);
  const [title,setTitle]=useState(''); const [time,setTime]=useState('09:00');
  const [loading,setLoading]=useState(true); const [error,setError]=useState(''); const [added,setAdded]=useState(false);

  const load=useCallback(async()=>{
    try { setLoading(true); setError(''); setItems(await apiJson<Reminder[]>('/api/data/reminders')); }
    catch { setError('We couldn’t load your reminders. Check that MongoDB is configured.'); }
    finally { setLoading(false); }
  },[]);
  useEffect(()=>{void load();},[load]);

  const add=async(e:FormEvent)=>{
    e.preventDefault(); if(!title.trim()) return;
    try {
      setError('');
      const item=await apiJson<Reminder>('/api/data/reminders',{method:'POST',body:JSON.stringify({title:title.trim(),time,dateLabel:'Tomorrow',enabled:true})});
      setItems(v=>[item,...v]); setTitle(''); setAdded(true);
    } catch { setError('We couldn’t save that reminder. Please try again.'); }
  };
  const toggle=async(item:Reminder)=>{
    try {
      const updated=await apiJson<Reminder>(`/api/data/reminders/${item.id}`,{method:'PATCH',body:JSON.stringify({enabled:!item.enabled})});
      setItems(v=>v.map(i=>i.id===item.id?updated:i));
    } catch { setError('We couldn’t update that reminder.'); }
  };
  const remove=async(id:string)=>{
    try { await apiJson<void>(`/api/data/reminders/${id}`,{method:'DELETE'}); setItems(v=>v.filter(i=>i.id!==id)); }
    catch { setError('We couldn’t delete that reminder.'); }
  };

  return <><PageTitle eyebrow="A little help remembering" title="Reminders" text="Your reminders are securely saved to your Healthify account."/>
    <div className="grid gap-5 xl:grid-cols-[.78fr_1.22fr]">
      <Card className="h-fit"><h2 className="mb-1 font-[Manrope] text-lg font-bold text-[#365650]">Create a reminder</h2>
        <p className="mb-5 text-sm text-[#849892]">Saved in MongoDB and scoped to your signed-in account.</p>
        <form onSubmit={add} className="space-y-4"><Field label="What would you like to remember?"><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Take a screen break" maxLength={80} className={inputClass}/></Field>
        <Field label="Time"><input type="time" value={time} onChange={e=>setTime(e.target.value)} className={inputClass}/></Field>
        <Button type="submit" disabled={!title.trim()} className="w-full"><Plus size={16}/>Add reminder</Button>
        {added&&<p role="status" className="text-sm text-[#0F766E]">Reminder saved.</p>}</form></Card>
      <Card><div className="mb-5 flex items-center justify-between"><div><Eyebrow>For your day</Eyebrow><h2 className="font-[Manrope] text-lg font-bold text-[#365650]">Your reminders</h2></div><span className="rounded-full bg-[#EAF6F2] px-3 py-1 text-xs font-bold text-[#367C72]">{items.length} total</span></div>
      {error&&<p role="alert" className="mb-3 rounded-xl bg-[#FFF1EF] p-3 text-sm text-[#9B433B]">{error}</p>}
      {loading?<p className="text-sm text-[#80958F]">Loading your reminders…</p>:items.length===0?<p className="rounded-2xl bg-[#F5F9F7] p-5 text-sm text-[#78918B]">No reminders yet. Add one to get started.</p>:
      <div className="space-y-3">{items.map(item=><div key={item.id} className="flex items-center gap-3 rounded-2xl border border-[#E5EEEB] p-4"><span className="grid size-10 shrink-0 place-items-center rounded-xl bg-[#EDF6F2] text-[#4B9388]"><BellRing size={18}/></span><div className="min-w-0 flex-1"><div className={`font-semibold ${item.enabled?'text-[#3C5A54]':'text-[#82928E]'}`}>{item.title}</div><div className="mt-1 text-xs text-[#879B95]">{item.dateLabel} · {new Date(`2000-01-01T${item.time}`).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}</div></div>
      <button onClick={()=>void toggle(item)} aria-pressed={item.enabled} className="min-h-10 rounded-xl bg-[#E9F5F1] px-3 text-xs font-semibold text-[#33796F]">{item.enabled?'On':'Off'}</button>
      <button onClick={()=>void remove(item.id)} aria-label={`Delete ${item.title}`} className="grid size-10 place-items-center rounded-xl text-[#9AABA6] hover:bg-[#FFF0EF]"><Trash2 size={16}/></button></div>)}</div>}</Card></div>
    <div className="mt-5 rounded-2xl border border-[#E6ECE9] bg-[#F9FBFA] p-4 text-sm leading-6 text-[#748A84]"><Info size={17} className="mr-2 inline"/>Reminders are persisted, but notification delivery still depends on a future browser/push notification integration.</div><Disclaimer/></>;
}

function Profile() {
 const [large,setLarge]=useState(false);const [contrast,setContrast]=useState(false);const [saved,setSaved]=useState(false);const {user}=useUser();
 useEffect(()=>{document.documentElement.style.fontSize=large?'18px':'';return()=>{document.documentElement.style.fontSize=''}},[large]);
 useEffect(()=>{document.documentElement.dataset.highContrast=contrast?'true':'false';return()=>{delete document.documentElement.dataset.highContrast}},[contrast]);
 const toggles=[{label:'Larger text',detail:'Make interface text easier to read.',icon:Accessibility,value:large,set:setLarge},{label:'Higher contrast',detail:'Increase contrast for key elements.',icon:Eye,value:contrast,set:setContrast}];
 return <><PageTitle eyebrow="Your account" title="Profile & privacy" text="Your account and accessibility preferences, in one comfortable place."/><div className="grid gap-5 xl:grid-cols-[.85fr_1.15fr]"><div className="space-y-5"><Card><div className="flex items-center gap-4"><div className="grid size-16 place-items-center rounded-[22px] bg-[#DDF1EB] font-[Manrope] text-2xl font-bold text-[#1F756B]">{(user?.firstName||'A').slice(0,1)}</div><div><h2 className="font-[Manrope] text-xl font-bold text-[#34534F]">{user?.fullName||'Aarav Sharma'}</h2><p className="mt-1 text-sm text-[#80958F]">{user?.primaryEmailAddress?.emailAddress||'Demo profile'} {user?null:<DemoTag/>}</p></div></div><div className="mt-6 rounded-xl bg-[#F5F9F7] p-4"><div className="flex items-center gap-2 text-sm font-semibold text-[#45635D]"><ShieldCheck size={16} className="text-[#0F766E]"/>Your details are private</div><p className="mt-2 text-xs leading-5 text-[#829791]">Your family members cannot access your information unless you explicitly choose to share it.</p></div></Card><Card><Eyebrow>Privacy choices</Eyebrow><h2 className="font-[Manrope] text-lg font-bold text-[#365650]">How your information is handled</h2><div className="mt-4 space-y-3">{[['Account security','Sign-in is handled securely by Clerk.'],['Health report files','Files are sent only with an analysis request and are not saved here.'],['Family access','No access is granted automatically.']].map(([a,b],i)=><div key={a} className="flex gap-3 border-b border-[#EDF2F0] pb-3 last:border-0"><CheckCircle2 size={17} className="mt-0.5 shrink-0 text-[#43A093]"/><div><h3 className="text-sm font-semibold text-[#4A6761]">{a}</h3><p className="mt-1 text-xs leading-5 text-[#859A94]">{b}</p></div></div>)}</div></Card></div><div className="space-y-5"><Card><Eyebrow>Accessibility</Eyebrow><h2 className="font-[Manrope] text-lg font-bold text-[#365650]">Make Healthify comfortable for you</h2><div className="mt-3 divide-y divide-[#EDF2F0]">{toggles.map(({label,detail,icon:Icon,value,set})=><div key={label} className="flex items-center gap-3 py-4"><span className="grid size-10 place-items-center rounded-xl bg-[#EEF7F3] text-[#3E8C80]"><Icon size={18}/></span><div className="flex-1"><h3 className="text-sm font-semibold text-[#45635D]">{label}</h3><p className="mt-1 text-xs text-[#859A94]">{detail}</p></div><button role="switch" aria-checked={value} aria-label={label} data-testid={`switch-${label.toLowerCase().replaceAll(' ','-')}`} onClick={()=>{set(!value);setSaved(true)}} className={`relative h-7 w-12 rounded-full transition ${value?'bg-[#0F766E]':'bg-[#D9E4E0]'}`}><span className={`absolute top-1 size-5 rounded-full bg-white shadow-sm transition-transform ${value?'translate-x-6':'translate-x-1'}`}/></button></div>)}</div>{saved&&<p role="status" className="mt-2 text-xs text-[#0F766E]">Your preference is applied for this visit.</p>}</Card><Card><Eyebrow>Language & help</Eyebrow><button data-testid="button-language-preference" onClick={()=>alert('Language options are not available yet.')} className="flex min-h-12 w-full items-center gap-3 rounded-xl px-2 text-left hover:bg-[#F5F9F7]"><Languages size={19} className="text-[#498F84]"/><span className="flex-1 text-sm font-semibold text-[#4B6862]">Language</span><span className="text-sm text-[#879B95]">English</span><ChevronRight size={16} className="text-[#9BAEA9]"/></button><button data-testid="button-profile-help" onClick={()=>alert('Help resources are being prepared.')} className="mt-1 flex min-h-12 w-full items-center gap-3 rounded-xl px-2 text-left hover:bg-[#F5F9F7]"><CircleHelp size={19} className="text-[#498F84]"/><span className="flex-1 text-sm font-semibold text-[#4B6862]">Help & support</span><ChevronRight size={16} className="text-[#9BAEA9]"/></button></Card></div></div><Disclaimer/></>;
}

function ClerkProviderWithRoutes() {
  const [,setLocation]=useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} localization={{signIn:{start:{title:'Welcome back',subtitle:'Your health space is ready when you are.'}},signUp:{start:{title:'Create your health space',subtitle:'A calmer way to care for yourself and your family.'}}}} routerPush={to=>setLocation(stripBase(to))} routerReplace={to=>setLocation(stripBase(to),{replace:true})}>
    <QueryClientProvider client={queryClient}>
      <Switch>
        <Route path="/" component={HomeRedirect}/>
        <Route path="/sign-in/*?" component={SignInPage}/>
        <Route path="/sign-up/*?" component={SignUpPage}/>
        <Route path="/login" component={AliasSignIn}/>
        <Route path="/signup" component={AliasSignUp}/>
        <Route path="/forgot-password" component={ForgotPassword}/>
        <Route path="/dashboard"><Protected><Dashboard/></Protected></Route>
        <Route path="/ai-assistant"><Protected><Assistant/></Protected></Route>
        <Route path="/reports"><Protected><Reports/></Protected></Route>
        <Route path="/family"><Protected><Family/></Protected></Route>
        <Route path="/family/:id"><Protected><Family/></Protected></Route>
        <Route path="/find-care"><Protected><FindCare/></Protected></Route>
        <Route path="/my-plan"><Protected><WellnessPlan/></Protected></Route>
        <Route path="/diet"><Protected><Diet/></Protected></Route>
        <Route path="/fitness"><Protected><Fitness/></Protected></Route>
        <Route path="/notifications"><Protected><Notifications/></Protected></Route>
        <Route path="/profile"><Protected><Profile/></Protected></Route>
        <Route component={NotFound}/>
      </Switch>
    </QueryClientProvider>
  </ClerkProvider>;
}
function App() {
  return <WouterRouter base={basePath}><ClerkProviderWithRoutes/></WouterRouter>;
}

export default App;