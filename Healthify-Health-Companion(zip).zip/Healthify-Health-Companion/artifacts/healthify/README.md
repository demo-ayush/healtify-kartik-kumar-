# HEALTHIFY

HEALTHIFY is a responsive health companion for organizing everyday care, understanding reports, and exploring general wellness. It is an educational tool, not a clinician, diagnosis, emergency service, or replacement for professional medical advice.

## What works

- Public landing page and Clerk sign-in/sign-up routes.
- Authenticated dashboard and app pages for AI health education, report explanation, family, care search, wellness, meals, activity, reminders, and profile settings.
- Gemini-powered chat, report explanation, wellness suggestions, and meal ideas. AI requests run on the API server and require a signed-in Clerk user.
- PDF, JPEG, and PNG report analysis (up to 5 MB). File bytes are validated and used only for that request; report files and analyses are not stored.
- Voice input through browser speech recognition where supported and spoken answer playback through browser speech synthesis.
- Clearly labeled demo/sample dashboard and wearable information; family and reminders are now MongoDB-backed.

## Current limits

- **Care search:** Google Places is connected through a server-side route. It returns place names/addresses/maps links only; Healthify does not claim clinical quality, ratings, appointments, or availability. `GOOGLE_MAPS_API_KEY` is required for this feature.
- **Persistence:** MongoDB stores authenticated family members and reminders, scoped by Clerk user ID. Wearable/activity data remains demo-only until a real device integration is connected.
- **Report privacy:** Uploaded reports and their AI explanations are transient; they are never saved to the database or object storage.
- **Notifications and devices:** Reminder delivery and wearable connections are not connected.

MongoDB is the only application database used by HEALTHIFY. Family data is private by default and report files are never persisted.

## Environment setup

The Replit web/API workflows supply `PORT` and `BASE_PATH`. Do not commit real secrets or copy production values into development.

| Variable | Used by | Purpose |
| --- | --- | --- |
| `GEMINI_API_KEY` | API server only | Calls Gemini 2.5 Flash for the four AI features. Store in Replit Secrets. |
| `CLERK_SECRET_KEY` | API server only | Verifies signed-in users and powers the Clerk proxy. Provision through the workspace Auth setup. |
| `CLERK_PUBLISHABLE_KEY` | API server | Clerk server middleware configuration. Provision through the workspace Auth setup. |
| `VITE_CLERK_PUBLISHABLE_KEY` | Web app | Public Clerk key used by the sign-in UI. Provision through the workspace Auth setup; it is not an API secret. |
| `VITE_CLERK_PROXY_URL` | Web app, optional | Full origin plus `/api/__clerk` when a Clerk proxy URL is required. In local development, direct Clerk API access can be used instead. |
| `GOOGLE_MAPS_API_KEY` | API server only | Google Places Text Search key for live care-location lookup; keep it server-side. |
| `MONGODB_URI` | API server only | MongoDB Atlas connection string for application persistence. |
| `MONGODB_DB_NAME` | API server only | MongoDB database name; defaults to `healthify`. |

### Replit development

1. In the workspace **Secrets** tool, add `GEMINI_API_KEY`. Never put the value in this file, browser code, logs, or chat.
2. In the workspace **Auth** setup, confirm Clerk is configured. Its publishable and secret keys are provisioned for the app.
3. Start the configured `artifacts/api-server: API Server` and `artifacts/healthify: web` workflows.
4. Open the HEALTHIFY preview. Create/sign in to an account to use the protected AI endpoints.

Development and production secrets are stored separately. Add `GEMINI_API_KEY` to production Secrets before publishing. Replit-managed Clerk Auth automatically swaps development test keys for production live keys when the app is published; do not copy development Clerk keys into production. A separately managed Clerk instance needs its own matching production credentials.

### Local development outside Replit

Use Node.js and pnpm versions compatible with the root workspace, then install the workspace:

```bash
pnpm install
```

Copy `.env.example` to an untracked `artifacts/healthify/.env`, fill it with your own development values, and never commit it. Before starting either process, export those variables into the shell:

```bash
set -a
. artifacts/healthify/.env
set +a
```

Run that in both terminals so the API receives server-side keys and Vite receives the publishable key.

Start the API server in one terminal:

```bash
PORT=3001 pnpm --filter @workspace/api-server run dev
```

Start the web app in another terminal:

```bash
API_PROXY_TARGET=http://localhost:3001 PORT=5173 BASE_PATH=/ pnpm --filter @workspace/healthify run dev
```

`API_PROXY_TARGET` enables Vite's local `/api` proxy. Replit's configured artifact routing handles `/api` without this setting.

## API contract and type generation

The OpenAPI source is `lib/api-spec/openapi.yaml`. Generated React Query hooks and Zod request schemas are checked into their workspace packages. After changing the API contract, regenerate them with:

```bash
pnpm --filter @workspace/api-spec run codegen
```

The API server validates every AI request, verifies the Clerk user, applies a per-user short-term request limit, and avoids logging request bodies. Gemini credentials are sent only from the server in an HTTP header.

## Database setup

HEALTHIFY uses MongoDB for application persistence. Set `MONGODB_URI` to a MongoDB Atlas connection string and optionally `MONGODB_DB_NAME` (defaults to `healthify`) in Replit Secrets. The API connects server-side only and scopes reminders and family members by the authenticated Clerk user ID.

Persisted collections currently include:
- `reminders` — user-created reminders and enabled/disabled state.
- `family_members` — family directory entries and explicit View/Edit/No access permission.

Health reports remain transient by design and are never stored. AI prompts/results are not persisted. Wearable measurements are not fabricated or stored until a real device integration is added.

Do not expose `MONGODB_URI` or any database credential through a `VITE_` variable.

## Google Maps / Places setup

Live care search is not enabled in this build. To add it, implement a server-side Places search route first, then create a Google Cloud API key with only the required Places API access, restrict it appropriately, and save it as the `GOOGLE_MAPS_API_KEY` Replit Secret. Do not expose that key as a `VITE_` variable. Until the route and key are configured, the app shows the unavailable state and no provider results.

## Hackathon demo

1. Create or sign into a Clerk account.
2. Use the dashboard to open **Ask Healthify**, **Health reports**, **My wellness plan**, and **Meal ideas**. These invoke the real Gemini-backed API.
3. Use a non-sensitive sample PDF or image for the report flow. The upload is analyzed in memory and not retained.
4. Demonstrate real MongoDB-backed family and reminder CRUD. Wearable/activity screens remain clearly labeled demo data because no device provider is connected.
5. Open **Find care** to demonstrate the transparent unavailable state. Do not present fabricated listings as live results.
6. If voice recognition is unavailable in the browser, use the text input; answer playback uses the browser's speech synthesis support.

## Publish

1. Verify the development workflows and add `GEMINI_API_KEY` to the deployment's **production secrets**. Replit-managed Clerk Auth supplies the production keys when published.
2. Open Replit's Publishing tool, review the app's access/domain settings and deployment configuration, then select **Publish**.
3. After publishing, verify sign-in, the API health state, and AI requests on the published app. Do not add report data or other real health information to the demo-only screens.