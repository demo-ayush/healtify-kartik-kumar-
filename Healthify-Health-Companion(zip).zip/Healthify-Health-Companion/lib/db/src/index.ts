import { MongoClient, type Db, type Collection, ObjectId } from "mongodb";

const uri = process.env.MONGODB_URI;
const dbName = process.env.MONGODB_DB_NAME || "healthify";

if (!uri) {
  throw new Error("MONGODB_URI must be set. Add your MongoDB Atlas connection string to Replit Secrets.");
}

const globalForMongo = globalThis as typeof globalThis & {
  __healthifyMongoReady?: Promise<Db>;
  __healthifyMongoClient?: MongoClient;
};

export function getMongoDb(): Promise<Db> {
  if (globalForMongo.__healthifyMongoReady) return globalForMongo.__healthifyMongoReady;

  const client = new MongoClient(uri, {
    maxPoolSize: 10,
    serverSelectionTimeoutMS: 5000,
  });
  globalForMongo.__healthifyMongoClient = client;
  globalForMongo.__healthifyMongoReady = (async () => {
    await client.connect();
    const db = client.db(dbName);
    await Promise.all([
      db.collection("reminders").createIndex({ userId: 1, createdAt: -1 }),
      db.collection("family_members").createIndex({ ownerId: 1, createdAt: 1 }),
    ]);
    return db;
  })().catch((error) => {
    globalForMongo.__healthifyMongoReady = undefined;
    globalForMongo.__healthifyMongoClient = undefined;
    void client.close().catch(() => {});
    throw error;
  });

  return globalForMongo.__healthifyMongoReady;
}

export async function getCollection<T extends object>(
  name: string,
): Promise<Collection<T>> {
  return (await getMongoDb()).collection<T>(name);
}

export function toObjectId(id: string): ObjectId | null {
  return ObjectId.isValid(id) ? new ObjectId(id) : null;
}

export async function closeMongo(): Promise<void> {
  await globalForMongo.__healthifyMongoClient?.close();
  globalForMongo.__healthifyMongoClient = undefined;
  globalForMongo.__healthifyMongoReady = undefined;
}
