# HEALTHIFY audit and fixes

## What was verified

- React/Vite frontend is connected to the Express API for Gemini chat, report analysis, wellness plans, and meal plans.
- Gemini API credentials remain server-side in `GEMINI_API_KEY`.
- Clerk authentication is enforced on AI and data routes.
- Report uploads are validated by MIME type, base64 shape, file signature, and 5 MB size.
- AI responses are parsed through Zod-generated response schemas.
- Emergency-looking chat phrases are handled before an AI answer is shown.
- No real secrets were found in the source tree.

## Problems found in the original Replit build

1. MongoDB was not implemented at all. The project described PostgreSQL/Drizzle, but HEALTHIFY had no health-specific tables or persistence routes.
2. Reminders were only React state/browser-session demo data.
3. Family members and permissions were hard-coded demo data and never persisted.
4. Activity/wearable values were hard-coded sample data.
5. Care search accepted input but intentionally never performed a provider search.
6. The health-check endpoint returned `ok` without checking the database.
7. The project contained stale PostgreSQL/Drizzle configuration that conflicted with the requested MongoDB architecture.

## Fixes made

- Replaced the unused Drizzle/PostgreSQL app database with the official MongoDB Node.js driver.
- Added MongoDB connection pooling, retry-safe initialization, and indexes.
- Added authenticated MongoDB CRUD for reminders.
- Added authenticated MongoDB CRUD for family members with explicit View/Edit/No access permissions.
- Updated the frontend reminder and family pages to use the real API instead of local demo state.
- Added a MongoDB-aware `/api/healthz`.
- Added a server-side Google Places Text Search route for Find Care; the API key never reaches the browser.
- Updated Find Care to display only provider data actually returned by Google Places.
- Removed stale PostgreSQL/Drizzle runtime dependencies and configuration.
- Updated `.env.example`, README, and Replit project metadata.
- Kept wearable/activity data explicitly demo-only until a real device integration is added.
- Kept report files transient and did not add health-report persistence.
- Added this audit so future edits do not accidentally reintroduce mock data.

## Required Replit Secrets

- `GEMINI_API_KEY` — required for AI features.
- `MONGODB_URI` — required for MongoDB persistence.
- `MONGODB_DB_NAME` — optional; defaults to `healthify`.
- Clerk values — provisioned by Replit Auth / Clerk.
- `GOOGLE_MAPS_API_KEY` — optional; required only for live Find Care results.

## Important

After changing dependencies, run `pnpm install` to regenerate `pnpm-lock.yaml`.

MongoDB Atlas network access must permit the Replit deployment. Do not expose `MONGODB_URI`, `GEMINI_API_KEY`, or `GOOGLE_MAPS_API_KEY` as `VITE_` variables.
