---
name: HEALTHIFY trust constraints
description: User-stated privacy and medical-safety rules for HEALTHIFY.
---

- HEALTHIFY must not diagnose or present itself as a clinician. Clearly label demo health, family, appointment, and wearable values. Never invent medical results or care providers.
- For potentially urgent symptoms, advise contacting local emergency services or seeking immediate care; do not reassure the user that the symptoms are harmless.
- Uploaded report files and their analysis are transient and must not be persisted.
- Family health data stays private unless the person explicitly grants access.

**Why:** The user requires a trustworthy, privacy-conscious health companion and explicitly prohibits fabricated medical and provider information.

**How to apply:** Check AI prompts and responses, report upload changes, provider search, family permissions, and any data-storage work against these rules before implementation.