# Healthyfy AI — corrected runnable build

Healthyfy AI is a React + Express health-management demo with Gemini-powered report analysis, AI chat, nutrition planning, family records, doctor discovery/booking, fitness demo data, notifications, and account settings.

## Requirements
- Node.js 20+ (22 LTS recommended)
- npm 10+
- A Gemini API key for AI features

## Run locally

1. Extract the ZIP.
2. Open a terminal in the project folder.
3. Install dependencies:

   `npm install`

4. Copy `.env.example` to `.env`.
5. Put your Gemini key in `GEMINI_API_KEY`.
6. Set a private `JWT_SECRET` (especially before deployment).
7. Start:

   `npm run dev`

8. Open `http://localhost:3000`.

The server runs the Vite development middleware and Express API together.

## Production build

`npm install`

`npm run build`

Set:

- `NODE_ENV=production`
- `JWT_SECRET=<long-random-secret>`
- `GEMINI_API_KEY=<your-key>`
- `PORT=3000`

Then run:

`npm start`

Open `http://localhost:3000`.

## Demo account

- Email: `kartik@healthyfy.ai`
- Password: `healthyfy123`

Create a new account if you prefer. Authentication is required for protected APIs; the server no longer silently logs unauthenticated requests in as the demo user.

## Important corrected behavior

- Family members, reports, AI context, notifications, and appointments are scoped to the authenticated user.
- Invalid/expired JWTs return 401.
- PDF and image reports are sent to Gemini as binary inline data instead of being incorrectly read as text.
- AI failure no longer invents medical lab values.
- Doctor booking uses a server endpoint and rejects conflicting slots.
- Profile and notification preferences are saved through the API.
- Fitness data remains explicitly demo/simulated data.
- The Gemini API key stays server-side; it is never placed in the React bundle.

## Medical disclaimer

Healthyfy AI is a software demo and educational health-information tool. AI output is not a diagnosis and must not replace a qualified clinician. Do not use the demo in an emergency; call local emergency services or seek urgent medical care.


## MongoDB setup

This version stores application data in MongoDB instead of keeping accounts and health records only in server memory.

1. Create a MongoDB Atlas cluster (or use a local MongoDB server).
2. Create a database user and allow your development IP in Atlas Network Access.
3. Copy `.env.example` to `.env`.
4. Set:
   - `MONGODB_URI` to your MongoDB connection string.
   - `MONGODB_DB_NAME=healthyfy`
5. Run `npm install`.
6. Run `npm run dev`.

The first startup creates the `healthyfy.app_state` document with the existing Kartik demo account and demo data. Later registrations, family members, medical reports, notifications, appointments, and fitness sync settings are persisted to MongoDB.

### Authentication behavior

- Sign Up creates a new account only from the Sign Up form.
- Sign In checks the stored bcrypt password hash.
- A wrong password is rejected with `Invalid email or password.` and cannot create an account.
- An existing email cannot be registered twice.
- Email addresses are normalized to lowercase.

